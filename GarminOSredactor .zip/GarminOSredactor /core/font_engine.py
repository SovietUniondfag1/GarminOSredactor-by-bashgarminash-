#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Garmin Font Engine — parse, render, and edit Garmin bitmap fonts.
Supports the Flawia/GUNP font format used in GPSMAP 60/70 series.

Font file format (disassembled by Flawia team, reverse engineered):
  HEADER (36 bytes):
    [0:4]   LE32  marker (0x24 = 36)
    [4:8]   LE32  total file size
    [8:12]  LE32  header/table size (0x24 = 36)
    [12:16] LE32  header size variant (0x28 = 40)
    [16:20] LE32  bitmap data start offset (0x2A0, 0x3A8, 0x3EC etc.)
    [20:22] LE16  reserved (0)
    [22:24] LE16  height + 1 (e.g. 9 for 8px font)
    [24:26] LE16  height in pixels (8, 10, 13, 17, 23, 46)
    [26:28] LE16  bits per pixel (1 = monochrome)
    [28:30] LE16  format flag (1)
    [30:32] LE16  bytes per row / char width in bytes (1 = 8px, 2 = 16px)
    [32:36] 4B   signature bytes (0x12345678)

  TABLE (offset 36 to bitmap_data_start):
    Variable-length entries mapping character codes to glyph offsets.
    Entry format: LE16 glyph_offset (relative to bitmap_data_start).

  BITMAP DATA (offset bitmap_data_start to EOF):
    Raw 1bpp pixel data. Each glyph = height * bytes_per_row bytes.
    Glyphs may be linked (same offset = same bitmap).
"""

import struct
from typing import List, Optional, Tuple


class Glyph:
    """Single character glyph — pixel grid + metadata."""

    def __init__(self, char_code: int, width: int, height: int,
                 pixels: Optional[List[List[bool]]] = None):
        self.char_code = char_code
        self.width = width
        self.height = height
        self.pixels = pixels or [[False] * width for _ in range(height)]

    @property
    def char(self) -> str:
        if 32 <= self.char_code < 127:
            return chr(self.char_code)
        if 0x0400 <= self.char_code <= 0x04FF:
            try:
                return chr(self.char_code)
            except Exception:
                pass
        return f'0x{self.char_code:04X}'

    @property
    def is_empty(self) -> bool:
        return all(not p for row in self.pixels for p in row)

    def get_pixel(self, row: int, col: int) -> bool:
        if 0 <= row < self.height and 0 <= col < self.width:
            return self.pixels[row][col]
        return False

    def set_pixel(self, row: int, col: int, value: bool):
        if 0 <= row < self.height and 0 <= col < self.width:
            self.pixels[row][col] = value

    def toggle_pixel(self, row: int, col: int):
        if 0 <= row < self.height and 0 <= col < self.width:
            self.pixels[row][col] = not self.pixels[row][col]

    def clear(self):
        self.pixels = [[False] * self.width for _ in range(self.height)]

    def invert(self):
        self.pixels = [[not p for p in row] for row in self.pixels]

    def to_bitmap(self) -> bytes:
        bpr = (self.width + 7) // 8
        result = bytearray()
        for row in range(self.height):
            row_val = 0
            for col in range(self.width):
                if self.pixels[row][col]:
                    row_val |= (1 << (7 - (col % 8)))
            for b in range(bpr):
                result.append((row_val >> (8 * (bpr - 1 - b))) & 0xFF)
        return bytes(result)

    def copy(self) -> 'Glyph':
        new_pixels = [row[:] for row in self.pixels]
        return Glyph(self.char_code, self.width, self.height, new_pixels)


class GarminFont:
    """Complete Garmin font file (Flawia/GUNP format)."""

    FONT_MARKER = 0x24

    def __init__(self, char_width: int = 8, char_height: int = 8):
        self.char_width = char_width
        self.char_height = char_height
        self.bytes_per_row = (char_width + 7) // 8
        self.bytes_per_glyph = self.bytes_per_row * char_height
        self.glyphs: dict[int, Glyph] = {}
        self.signature = bytes([0x12, 0x34, 0x56, 0x78])
        self.format_flag = 1
        self.bpp = 1

    @property
    def height_plus_one(self) -> int:
        return self.char_height + 1

    @property
    def glyph_count(self) -> int:
        return len(self.glyphs)

    def set_glyph(self, char_code: int, glyph: Glyph):
        self.glyphs[char_code] = glyph

    def get_glyph(self, char_code: int) -> Optional[Glyph]:
        return self.glyphs.get(char_code)

    def create_empty_glyph(self, char_code: int) -> Glyph:
        return Glyph(char_code, self.char_width, self.char_height)

    @classmethod
    def from_bytes(cls, data: bytes) -> 'GarminFont':
        if len(data) < 36:
            raise ValueError(f"Font data too small: {len(data)} bytes (need >= 36)")

        # Parse header (marker is first byte 0x24, bytes 2-3 may be version)
        marker = data[0]
        if marker != 0x24:
            raise ValueError(f"Invalid font marker: {marker:#x} (expected 0x24)")

        file_size = struct.unpack('<I', data[4:8])[0]
        if file_size != len(data):
            raise ValueError(f"Size mismatch: header says {file_size}, got {len(data)}")

        height_p1 = struct.unpack('<H', data[22:24])[0]
        height = struct.unpack('<H', data[24:26])[0]
        bpp = struct.unpack('<H', data[26:28])[0]
        fmt = struct.unpack('<H', data[28:30])[0]
        bpr = struct.unpack('<H', data[30:32])[0]
        sig = data[32:36]

        bitmap_start = struct.unpack('<I', data[16:20])[0]
        table_start = 36

        if bpr == 0:
            bpr = 1
        char_width = bpr * 8

        font = cls(char_width, height)
        font.bpp = bpp
        font.format_flag = fmt
        font.signature = sig

        # Bitmap data area
        bitmap_data = data[bitmap_start:]
        total_bitmap_bytes = len(bitmap_data)
        n_possible_glyphs = total_bitmap_bytes // font.bytes_per_glyph

        # Table area: from offset 36 to bitmap_start
        table_data = data[table_start:bitmap_start]

        # Parse table: each entry is LE16 offset into bitmap area
        # Table maps character index → glyph bitmap offset
        n_table_entries = len(table_data) // 2
        offsets_seen = {}  # offset → Glyph object (for linking)

        for i in range(n_table_entries):
            off = i * 2
            glyph_offset = struct.unpack('<H', table_data[off:off+2])[0]

            char_code = i

            # Get or create glyph
            if glyph_offset in offsets_seen:
                # Linked glyph — reuse same pixels
                linked = offsets_seen[glyph_offset].copy()
                linked.char_code = char_code
                font.glyphs[char_code] = linked
            else:
                # New glyph
                if glyph_offset + font.bytes_per_glyph <= total_bitmap_bytes:
                    raw = bitmap_data[glyph_offset:glyph_offset + font.bytes_per_glyph]
                    pixels = []
                    for row in range(height):
                        row_pixels = []
                        for col in range(char_width):
                            byte_idx = row * bpr + col // 8
                            bit_idx = 7 - (col % 8)
                            if byte_idx < len(raw):
                                on = bool(raw[byte_idx] & (1 << bit_idx))
                            else:
                                on = False
                            row_pixels.append(on)
                        pixels.append(row_pixels)
                    glyph = Glyph(char_code, char_width, height, pixels)
                    offsets_seen[glyph_offset] = glyph
                    font.glyphs[char_code] = glyph
                else:
                    glyph = Glyph(char_code, char_width, height)
                    offsets_seen[glyph_offset] = glyph
                    font.glyphs[char_code] = glyph

        return font

    @classmethod
    def load(cls, filepath: str) -> 'GarminFont':
        with open(filepath, 'rb') as f:
            data = f.read()
        return cls.from_bytes(data)

    def to_bytes(self) -> bytes:
        # Build offset table + bitmap data
        unique_glyphs = {}  # char_code → (glyph, is_first)
        bitmap_offset_map = {}  # id(glyph_data) → offset
        bitmap_data = bytearray()
        table_entries = []

        # Determine max char code
        if not self.glyphs:
            max_code = 255
        else:
            max_code = max(self.glyphs.keys())

        for i in range(max_code + 1):
            glyph = self.glyphs.get(i)
            if glyph is None:
                glyph = Glyph(i, self.char_width, self.char_height)

            glyph_id = id(glyph)
            if glyph_id in bitmap_offset_map:
                # Linked — reuse offset
                table_entries.append(bitmap_offset_map[glyph_id])
            else:
                offset = len(bitmap_data)
                bitmap_offset_map[glyph_id] = offset
                table_entries.append(offset)
                bitmap_data.extend(glyph.to_bitmap())

        # Build header
        table_size = len(table_entries) * 2
        bitmap_start = 36 + table_size
        total_size = bitmap_start + len(bitmap_data)

        header = bytearray(36)
        struct.pack_into('<I', header, 0, 0x24)           # marker
        struct.pack_into('<I', header, 4, total_size)     # file size
        struct.pack_into('<I', header, 8, 0x24)           # header size
        struct.pack_into('<I', header, 12, 0x28)          # header variant
        struct.pack_into('<I', header, 16, bitmap_start)  # bitmap data start
        struct.pack_into('<H', header, 20, 0)             # reserved
        struct.pack_into('<H', header, 22, self.char_height + 1)  # height+1
        struct.pack_into('<H', header, 24, self.char_height)       # height
        struct.pack_into('<H', header, 26, self.bpp)               # bpp
        struct.pack_into('<H', header, 28, self.format_flag)       # format
        struct.pack_into('<H', header, 30, self.bytes_per_row)     # bytes per row
        header[32:36] = self.signature                           # signature

        # Build table
        table = bytearray()
        for off in table_entries:
            table.extend(struct.pack('<H', off))

        return bytes(header) + bytes(table) + bytes(bitmap_data)

    def save(self, filepath: str):
        with open(filepath, 'wb') as f:
            f.write(self.to_bytes())

    def get_filled_glyph_count(self) -> int:
        return sum(1 for g in self.glyphs.values() if not g.is_empty)

    def get_linked_glyph_count(self) -> int:
        seen_bitmaps = set()
        linked = 0
        for g in self.glyphs.values():
            bm = tuple(tuple(row) for row in g.pixels)
            if bm in seen_bitmaps:
                linked += 1
            else:
                seen_bitmaps.add(bm)
        return linked

    def export_glyph_at(self, char_code: int, output_path: str):
        g = self.get_glyph(char_code)
        if g:
            with open(output_path, 'wb') as f:
                f.write(g.to_bitmap())


def detect_font_format(data: bytes, offset: int = 0) -> Optional[dict]:
    """Detect if data at offset looks like a Garmin font header."""
    if offset + 36 > len(data):
        return None
    marker = struct.unpack('<I', data[offset:offset+4])[0]
    if marker != 0x24:
        return None
    file_size = struct.unpack('<I', data[offset+4:offset+8])[0]
    if file_size == 0 or file_size > 0x100000:
        return None
    height = struct.unpack('<H', data[offset+24:offset+26])[0]
    if height == 0 or height > 128:
        return None
    bpr = struct.unpack('<H', data[offset+30:offset+32])[0]
    if bpr == 0 or bpr > 16:
        return None
    bitmap_start = struct.unpack('<I', data[offset+16:offset+20])[0]
    if bitmap_start < 36 or bitmap_start >= file_size:
        return None
    return {
        'offset': offset,
        'file_size': file_size,
        'height': height,
        'char_width': bpr * 8,
        'bytes_per_row': bpr,
        'bitmap_start': bitmap_start,
        'marker': 0x24,
    }


def find_fonts_in_firmware(data: bytes) -> List[dict]:
    """Scan firmware binary for embedded Garmin fonts."""
    results = []
    pos = 0
    while True:
        pos = data.find(b'\x24\x00\x00\x00', pos)
        if pos < 0:
            break
        info = detect_font_format(data, pos)
        if info:
            results.append(info)
            pos += info['file_size']
        else:
            pos += 1
    return results
