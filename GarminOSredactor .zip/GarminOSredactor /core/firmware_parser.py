#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Garmin RGN Firmware Parser — core analysis engine.
Handles binary parsing, language section detection, font search, firmware comparison.
"""

import struct
import os
from typing import List, Dict, Optional, Tuple

# Language detection patterns: (byte_sequence, display_name)
# Patterns use 3+ consecutive month abbreviations to avoid false positives
LANG_PATTERNS = [
    (b'English\x00JAN\x00FEB\x00MAR\x00',      'English'),
    (b'Fran\xe7ais\x00JAN\x00FEV\x00MAR\x00',   'Fran\xe7ais'),
    (b'Espa\xf1ol\x00ENE\x00FEB\x00MAR\x00',    'Espa\xf1ol'),
    (b'Italiano\x00GEN\x00FEB\x00MAR\x00APR\x00','Italiano'),
    (b'Deutsch\x00JAN\x00FEB\x00MRZ\x00APR\x00', 'Deutsch'),
    (b'Svenska\x00JAN\x00FEB\x00MAR\x00APR\x00','Svenska'),
    (b'Dansk\x00JAN\x00FEB\x00MAR\x00APR\x00',  'Dansk'),
    (b'Norsk\x00JAN\x00FEB\x00MAR\x00APR\x00',  'Norsk'),
    (b'Portugu\xeas\x00JAN\x00FEV\x00MAR\x00',  'Portugu\xeas'),
    (b'Nederlands\x00JAN\x00FEB\x00MRT\x00APR\x00', 'Nederlands'),
    (b'Suomi\x00TAM\x00HEL\x00MAAL\x00HUH\x00', 'Suomi'),
    (b'Polski\x00STY\x00LUT\x00MAR\x00KWI\x00MAJ', 'Polski'),
    (b'Magyar\x00JAN\x00FEB\x00MAR\x00APR\x00', 'Magyar'),
    (b'Hrvatski\x00JAN\x00FEB\x00MAR\x00APR\x00', 'Hrvatski'),
    (b'Sloven\xc5\xa1\xc4\x8dina\x00JAN\x00FEB', 'Sloven\xc5\xa1\xc4\x8dina'),
    (b'Eesti\x00JAAN\x00VEEB\x00MAR\x00',       'Eesti'),
    (b'Latviski\x00JAN\x00FEB\x00MAR\x00APR\x00','Latviski'),
    (b'Lietuvi\xc5\xb3\x00SAU\x00VAS\x00KOV\x00','Lietuvi\xc5\xb3'),
    (b'T\xfcrk\xe7e\x00OCA\x00',                'T\xfcrk\xe7e'),
    (b'Russian\x00JAN\x00FEB\x00MAR\x00',       'Russian'),
]


class RgnHeader:
    """Parsed RGN file header."""

    def __init__(self, data: bytes):
        self.raw = data[:64] if len(data) >= 64 else data
        self.signature = data[0:4].hex(' ') if len(data) >= 4 else ''
        self.signature_ascii = data[0:4].decode('ascii', errors='replace') if len(data) >= 4 else ''
        self.field_04 = struct.unpack('<I', data[4:8])[0] if len(data) >= 8 else 0
        self.field_08 = struct.unpack('<I', data[8:12])[0] if len(data) >= 12 else 0
        self.field_0c = struct.unpack('<I', data[12:16])[0] if len(data) >= 16 else 0
        self.field_10 = struct.unpack('<I', data[16:20])[0] if len(data) >= 20 else 0
        self.region_tag = ''
        self.build_date = ''
        self.build_time = ''
        if len(data) >= 23 and data[20:23] == b'SQA':
            self.region_tag = 'SQA'
            date_raw = data[24:48].split(b'\x00')[0]
            time_raw = data[48:64].split(b'\x00')[0]
            self.build_date = date_raw.decode('ascii', errors='replace')
            self.build_time = time_raw.decode('ascii', errors='replace')


class LanguageSection:
    """One language section within firmware."""

    def __init__(self, name: str, offset: int, size: int,
                 string_count: int, data: bytes):
        self.name = name
        self.offset = offset
        self.size = size
        self.string_count = string_count
        self.data = data

    @property
    def strings(self) -> List[bytes]:
        return [s for s in self.data.split(b'\x00') if len(s) > 0]

    @property
    def avg_bytes_per_string(self) -> float:
        if self.string_count == 0:
            return 0.0
        return self.size / self.string_count

    @property
    def string_data_size(self) -> int:
        return sum(len(s) for s in self.strings)


class FirmwareFile:
    """Complete Garmin RGN firmware file."""

    def __init__(self, filepath: str = None, data: bytes = None):
        self.filepath = filepath
        self.filename = os.path.basename(filepath) if filepath else 'unknown'
        self.data = data
        self.header: Optional[RgnHeader] = None
        self.languages: List[LanguageSection] = []
        self.font_candidates: List[dict] = []

        if data:
            self._parse()

    def _parse(self):
        if len(self.data) < 64:
            return
        self.header = RgnHeader(self.data)
        self.languages = self._find_languages()
        self.font_candidates = self._find_fonts()

    @classmethod
    def load(cls, filepath: str) -> 'FirmwareFile':
        with open(filepath, 'rb') as f:
            data = f.read()
        return cls(filepath=filepath, data=data)

    def _find_languages(self) -> List[LanguageSection]:
        sections = []
        found_offsets = set()

        for pattern, name in LANG_PATTERNS:
            pos = self.data.find(pattern)
            while pos >= 0 and pos not in found_offsets:
                if pos < 0x10000:
                    pos = self.data.find(pattern, pos + 1)
                    continue
                if pos > 0 and 0x41 <= self.data[pos - 1] <= 0x7A:
                    pos = self.data.find(pattern, pos + 1)
                    continue
                found_offsets.add(pos)
                sections.append((name, pos))
                break

        sections.sort(key=lambda x: x[1])
        result = []
        for i, (name, offset) in enumerate(sections):
            if i < len(sections) - 1:
                size = sections[i + 1][1] - offset
            else:
                end = offset
                pos = offset
                null_run = 0
                while pos < len(self.data):
                    if self.data[pos] == 0:
                        null_run += 1
                        if null_run > 128:
                            end = pos - null_run + 1
                            break
                    else:
                        null_run = 0
                    pos += 1
                else:
                    end = len(self.data)
                size = end - offset

            sec_data = self.data[offset:offset + size]
            strings = [s for s in sec_data.split(b'\x00') if len(s) > 0]
            result.append(LanguageSection(name, offset, size, len(strings), sec_data))

        return result

    def _find_fonts(self) -> List[dict]:
        candidates = []
        for pattern in [b'font', b'FONT', b'Font', b'glyph', b'GLYPH']:
            pos = 0
            while True:
                pos = self.data.find(pattern, pos)
                if pos < 0:
                    break
                ctx = self.data[max(0, pos - 16):pos + 32]
                candidates.append({
                    'type': 'string_ref',
                    'offset': pos,
                    'pattern': pattern.decode('ascii', errors='replace'),
                    'context': ctx.hex(' ')
                })
                pos += 1
        return candidates

    @property
    def file_size(self) -> int:
        return len(self.data) if self.data else 0

    @property
    def total_lang_size(self) -> int:
        return sum(s.size for s in self.languages)

    @property
    def lang_area_start(self) -> int:
        return self.languages[0].offset if self.languages else 0

    @property
    def lang_area_end(self) -> int:
        if not self.languages:
            return 0
        last = self.languages[-1]
        return last.offset + last.size

    def get_language_by_index(self, index: int) -> Optional[LanguageSection]:
        if 0 <= index < len(self.languages):
            return self.languages[index]
        return None

    def export_language(self, index: int, output_path: str):
        sec = self.get_language_by_index(index)
        if sec:
            with open(output_path, 'wb') as f:
                f.write(sec.data)

    def replace_language_data(self, index: int, new_data: bytes) -> bool:
        sec = self.get_language_by_index(index)
        if not sec:
            return False
        if len(new_data) > sec.size:
            return False
        new_data_padded = new_data + b'\x00' * (sec.size - len(new_data))
        self.data = (self.data[:sec.offset] +
                     new_data_padded +
                     self.data[sec.offset + sec.size:])
        self._parse()
        return True

    def save(self, output_path: str):
        with open(output_path, 'wb') as f:
            f.write(self.data)


def compare_firmwares(fw1: FirmwareFile, fw2: FirmwareFile) -> str:
    lines = []
    lines.append("=" * 75)
    lines.append("СРАВНЕНИЕ ПРОШИВОК")
    lines.append("=" * 75)
    lines.append(f"{'Файл 1:':<20}{fw1.filename:<40}{fw1.file_size:>12,} байт")
    lines.append(f"{'Файл 2:':<20}{fw2.filename:<40}{fw2.file_size:>12,} байт")
    diff = fw2.file_size - fw1.file_size
    lines.append(f"{'Разница:':<20}{'':<40}{diff:>+12,} байт")
    lines.append("")

    map1 = {s.name: s for s in fw1.languages}
    map2 = {s.name: s for s in fw2.languages}
    all_names = sorted(set(list(map1.keys()) + list(map2.keys())))

    hdr = f"{'Язык':<22}{'Строки Ф1':>12}{'Строки Ф2':>12}{'Размер Ф1':>12}{'Размер Ф2':>12}{'Δ строк':>10}"
    lines.append(hdr)
    lines.append("-" * len(hdr))

    for name in all_names:
        s1 = map1.get(name)
        s2 = map2.get(name)
        c1 = s1.string_count if s1 else '—'
        c2 = s2.string_count if s2 else '—'
        z1 = f"{s1.size:,}" if s1 else '—'
        z2 = f"{s2.size:,}" if s2 else '—'
        d = ''
        if s1 and s2:
            dd = s2.string_count - s1.string_count
            d = f"{dd:+d}" if dd != 0 else '='
        lines.append(f"{name:<22}{c1:>12}{c2:>12}{z1:>12}{z2:>12}{d:>10}")

    common = [n for n in all_names if n in map1 and n in map2]
    only1 = [n for n in map1 if n not in map2]
    only2 = [n for n in map2 if n not in map1]
    lines.append(f"\nОбщих языков: {len(common)}")
    if only1:
        lines.append(f"Только в Ф1: {only1}")
    if only2:
        lines.append(f"Только в Ф2: {only2}")

    return '\n'.join(lines)
