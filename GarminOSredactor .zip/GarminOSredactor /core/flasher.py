#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Garmin Flasher — firmware upload via SD card preparation.
USB flashing placeholder (requires pyserial + Garmin USB protocol).
"""

import os
import shutil
import subprocess
from typing import Optional, List


def get_removable_drives() -> List[dict]:
    """Detect removable drives (SD cards, USB drives) on the system."""
    drives = []
    try:
        if os.name == 'nt':
            import string
            import ctypes
            bitmask = ctypes.windll.kernel32.GetLogicalDrives()
            for letter in string.ascii_uppercase:
                if bitmask & (1 << string.ascii_uppercase.index(letter)):
                    drive = f"{letter}:\\"
                    drive_type = ctypes.windll.kernel32.GetDriveTypeW(drive)
                    if drive_type == 2:  # DRIVE_REMOVABLE
                        try:
                            total, used, free = shutil.disk_usage(drive)
                            drives.append({
                                'path': drive,
                                'label': drive,
                                'free_gb': free / (1024**3),
                                'total_gb': total / (1024**3),
                            })
                        except OSError:
                            drives.append({'path': drive, 'label': drive,
                                           'free_gb': 0, 'total_gb': 0})
        else:
            # Linux: check /media and /mnt
            for base in ['/media', '/mnt', '/run/media']:
                if not os.path.exists(base):
                    continue
                for user in os.listdir(base):
                    user_path = os.path.join(base, user)
                    if not os.path.isdir(user_path):
                        continue
                    for mount in os.listdir(user_path):
                        mount_path = os.path.join(user_path, mount)
                        if os.path.ismount(mount_path):
                            try:
                                total, used, free = shutil.disk_usage(mount_path)
                                drives.append({
                                    'path': mount_path,
                                    'label': mount,
                                    'free_gb': free / (1024**3),
                                    'total_gb': total / (1024**3),
                                })
                            except OSError:
                                drives.append({'path': mount_path, 'label': mount,
                                               'free_gb': 0, 'total_gb': 0})
    except Exception:
        pass
    return drives


def prepare_sd_card(firmware_path: str, drive_path: str, callback=None) -> dict:
    """Copy firmware .rgn to SD card root for flashing.
    
    Instructions for user:
    1. Format SD card as FAT32
    2. Copy .rgn file to root
    3. Insert SD into Garmin
    4. Hold PAGE + POWER to enter update mode
    """
    if not os.path.isfile(firmware_path):
        return {'success': False, 'error': f'Файл не найден: {firmware_path}'}

    fw_size = os.path.getsize(firmware_path)

    if not os.path.isdir(drive_path):
        return {'success': False, 'error': f'Диск не найден: {drive_path}'}

    try:
        free = shutil.disk_usage(drive_path).free
        if free < fw_size:
            return {'success': False,
                    'error': f'Недостаточно места. Нужно {fw_size/1024/1024:.1f} МБ, '
                             f'свободно {free/1024/1024:.1f} МБ'}

        filename = os.path.basename(firmware_path)
        dest = os.path.join(drive_path, filename)

        if callback:
            callback(f'Копирование {filename}...')

        shutil.copy2(firmware_path, dest)

        if callback:
            callback(f'Готово! {filename} скопирован на {drive_path}')

        return {
            'success': True,
            'message': f'{filename} → {drive_path}',
            'instructions': (
                'ИНСТРУКЦИЯ ПО ПРОШИВКЕ:\n'
                '1. Вставьте SD-карту в навигатор Garmin\n'
                '2. Нажмите и удерживайте PAGE + POWER\n'
                '3. Дождитесь надписи "Software Loading..."\n'
                '4. Не выключайте устройство до завершения!\n'
                '5. Навигатор перезагрузится с новой прошивкой'
            )
        }
    except PermissionError:
        return {'success': False, 'error': 'Нет доступа к диску. Попробуйте запустить от имени администратора.'}
    except Exception as e:
        return {'success': False, 'error': str(e)}


def check_pyserial() -> bool:
    try:
        import serial
        return True
    except ImportError:
        return False


def get_serial_ports() -> List[str]:
    ports = []
    try:
        import serial.tools.list_ports
        for p in serial.tools.list_ports.comports():
            ports.append(f"{p.device} — {p.description}")
    except ImportError:
        pass
    return ports


def detect_garmin_usb() -> Optional[str]:
    if not check_pyserial():
        return None
    try:
        import serial.tools.list_ports
        for p in serial.tools.list_ports.comports():
            desc = p.description.lower()
            vid = f"VID:PID={p.vid}:{p.pid}" if p.vid else ''
            if 'garmin' in desc or 'gps' in desc or 'navi' in desc:
                return f"{p.device} — {p.description}"
            if p.vid == 0x091E:  # Garmin USB vendor ID
                return f"{p.device} — {p.description} (Garmin)"
    except ImportError:
        pass
    return None


def format_fat32(drive_path: str) -> dict:
    """Show instructions / attempt FAT32 formatting."""
    if os.name == 'nt':
        return {
            'success': False,
            'instructions': (
                f'Для форматирования SD-карты в FAT32:\n'
                f'1. Откройте "Мой компьютер"\n'
                f'2. Правый клик на {drive_path}\n'
                f'3. "Форматировать" → FAT32\n'
                f'4. Нажмите "Начать"\n\n'
                f'ПРИМЕЧАНИЕ: Для карт >32 ГБ FAT32 может не отображаться.\n'
                f'Используйте Rufus или GUIformat для больших карт.'
            )
        }
    else:
        return {
            'success': False,
            'instructions': (
                f'Для форматирования SD-карты в FAT32:\n'
                f'  sudo mkfs.vfat -F 32 {drive_path}\n\n'
                f'Или через GUI:\n'
                f'1. Откройте "Диски" (GNOME)\n'
                f'2. Выберите SD-карту\n'
                f'3. Нажмите значок шестерёнки → "Форматировать"\n'
                f'4. Тип: FAT32\n'
                f'5. Нажмите "Форматировать"'
            )
        }
