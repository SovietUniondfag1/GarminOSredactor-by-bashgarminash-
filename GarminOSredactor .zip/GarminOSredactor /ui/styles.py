#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QSS Stylesheets for GarminOSredactor — Dark and Light themes.
Garmin accent color: #00B050 (green).
"""

DARK_STYLE = """
/* GarminOSredactor Dark Theme */
QMainWindow {
    background-color: #1E1E2E;
}

QWidget {
    background-color: #1E1E2E;
    color: #E0E0E0;
    font-family: "Segoe UI", "Noto Sans", sans-serif;
    font-size: 13px;
}

QTabWidget::pane {
    border: 1px solid #3D3D4D;
    background-color: #1E1E2E;
    border-radius: 4px;
}

QTabBar::tab {
    background-color: #2D2D3D;
    color: #A0A0B0;
    padding: 8px 16px;
    margin-right: 2px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: bold;
}

QTabBar::tab:selected {
    background-color: #1E1E2E;
    color: #00B050;
    border-bottom: 2px solid #00B050;
}

QTabBar::tab:hover:!selected {
    background-color: #353545;
    color: #C0C0D0;
}

QMenuBar {
    background-color: #2D2D3D;
    color: #E0E0E0;
    border-bottom: 1px solid #3D3D4D;
    padding: 2px;
}

QMenuBar::item:selected {
    background-color: #00B050;
    color: white;
}

QMenu {
    background-color: #2D2D3D;
    color: #E0E0E0;
    border: 1px solid #3D3D4D;
    border-radius: 4px;
    padding: 4px;
}

QMenu::item:selected {
    background-color: #00B050;
    color: white;
    border-radius: 3px;
}

QMenu::separator {
    height: 1px;
    background-color: #3D3D4D;
    margin: 4px 8px;
}

QToolBar {
    background-color: #2D2D3D;
    border-bottom: 1px solid #3D3D4D;
    spacing: 4px;
    padding: 4px;
}

QPushButton {
    background-color: #2D2D3D;
    color: #E0E0E0;
    border: 1px solid #3D3D4D;
    border-radius: 6px;
    padding: 6px 16px;
    font-weight: bold;
    min-height: 24px;
}

QPushButton:hover {
    background-color: #353545;
    border-color: #00B050;
}

QPushButton:pressed {
    background-color: #00B050;
    color: white;
}

QPushButton:disabled {
    background-color: #252530;
    color: #606070;
    border-color: #2D2D3D;
}

QPushButton[class="primary"] {
    background-color: #00B050;
    color: white;
    border-color: #00B050;
}

QPushButton[class="primary"]:hover {
    background-color: #00C060;
}

QPushButton[class="danger"] {
    background-color: #FF4444;
    color: white;
    border-color: #FF4444;
}

QPushButton[class="danger"]:hover {
    background-color: #FF5555;
}

QGroupBox {
    background-color: #252535;
    border: 1px solid #3D3D4D;
    border-radius: 6px;
    margin-top: 12px;
    padding: 12px;
    padding-top: 24px;
    font-weight: bold;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: #00B050;
}

QTableWidget, QTableView {
    background-color: #252535;
    alternate-background-color: #282838;
    color: #E0E0E0;
    gridline-color: #3D3D4D;
    border: 1px solid #3D3D4D;
    border-radius: 4px;
    selection-background-color: #00B050;
    selection-color: white;
    font-size: 12px;
}

QTableWidget::item, QTableView::item {
    padding: 6px 8px;
    min-height: 28px;
}

QHeaderView::section {
    background-color: #2D2D3D;
    color: #00B050;
    padding: 8px 10px;
    border: 1px solid #3D3D4D;
    font-weight: bold;
    font-size: 12px;
    min-height: 28px;
}

QTextEdit, QPlainTextEdit {
    background-color: #252535;
    color: #E0E0E0;
    border: 1px solid #3D3D4D;
    border-radius: 4px;
    padding: 4px;
    font-family: "Consolas", "DejaVu Sans Mono", monospace;
    font-size: 12px;
}

QLineEdit {
    background-color: #252535;
    color: #E0E0E0;
    border: 1px solid #3D3D4D;
    border-radius: 4px;
    padding: 6px 10px;
    min-height: 24px;
}

QLineEdit:focus {
    border-color: #00B050;
}

QComboBox {
    background-color: #252535;
    color: #E0E0E0;
    border: 1px solid #3D3D4D;
    border-radius: 4px;
    padding: 6px 10px;
    min-height: 26px;
}

QComboBox::drop-down {
    border: none;
    width: 24px;
}

QComboBox QAbstractItemView {
    background-color: #2D2D3D;
    color: #E0E0E0;
    border: 1px solid #3D3D4D;
    selection-background-color: #00B050;
}

QListWidget {
    background-color: #252535;
    color: #E0E0E0;
    border: 1px solid #3D3D4D;
    border-radius: 4px;
    padding: 2px;
}

QListWidget::item:selected {
    background-color: #00B050;
    color: white;
}

QProgressBar {
    background-color: #252535;
    border: 1px solid #3D3D4D;
    border-radius: 6px;
    text-align: center;
    color: #E0E0E0;
    min-height: 20px;
}

QProgressBar::chunk {
    background-color: #00B050;
    border-radius: 5px;
}

QLabel {
    background-color: transparent;
    color: #E0E0E0;
}

QLabel[class="header"] {
    font-size: 18px;
    font-weight: bold;
    color: #00B050;
}

QLabel[class="warning"] {
    color: #FF6B35;
}

QLabel[class="error"] {
    color: #FF4444;
}

QLabel[class="success"] {
    color: #00B050;
}

QStatusBar {
    background-color: #2D2D3D;
    color: #A0A0B0;
    border-top: 1px solid #3D3D4D;
    font-size: 11px;
}

QStatusBar::item {
    border: none;
}

QScrollBar:vertical {
    background-color: #1E1E2E;
    width: 12px;
    border: none;
}

QScrollBar::handle:vertical {
    background-color: #3D3D4D;
    border-radius: 6px;
    min-height: 30px;
}

QScrollBar::handle:vertical:hover {
    background-color: #00B050;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar:horizontal {
    background-color: #1E1E2E;
    height: 12px;
    border: none;
}

QScrollBar::handle:horizontal {
    background-color: #3D3D4D;
    border-radius: 6px;
    min-width: 30px;
}

QSplitter::handle {
    background-color: #3D3D4D;
}

QDialog {
    background-color: #1E1E2E;
}

QMessageBox {
    background-color: #1E1E2E;
}

QToolTip {
    background-color: #2D2D3D;
    color: #E0E0E0;
    border: 1px solid #00B050;
    border-radius: 4px;
    padding: 4px;
}
"""

LIGHT_STYLE = """
/* GarminOSredactor Light Theme */
QMainWindow {
    background-color: #F5F5F5;
}

QWidget {
    background-color: #F5F5F5;
    color: #1A1A2E;
    font-family: "Segoe UI", "Noto Sans", sans-serif;
    font-size: 13px;
}

QTabWidget::pane {
    border: 1px solid #D0D0D0;
    background-color: #FFFFFF;
    border-radius: 4px;
}

QTabBar::tab {
    background-color: #E8E8E8;
    color: #666666;
    padding: 8px 20px;
    margin-right: 2px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: bold;
}

QTabBar::tab:selected {
    background-color: #FFFFFF;
    color: #007A3D;
    border-bottom: 2px solid #00B050;
}

QTabBar::tab:hover:!selected {
    background-color: #D8D8D8;
    color: #333333;
}

QMenuBar {
    background-color: #E8E8E8;
    color: #1A1A2E;
    border-bottom: 1px solid #D0D0D0;
}

QMenuBar::item:selected {
    background-color: #00B050;
    color: white;
}

QMenu {
    background-color: #FFFFFF;
    color: #1A1A2E;
    border: 1px solid #D0D0D0;
}

QMenu::item:selected {
    background-color: #00B050;
    color: white;
}

QPushButton {
    background-color: #FFFFFF;
    color: #1A1A2E;
    border: 1px solid #D0D0D0;
    border-radius: 6px;
    padding: 6px 16px;
    font-weight: bold;
}

QPushButton:hover {
    background-color: #E8F5E9;
    border-color: #00B050;
}

QPushButton:pressed {
    background-color: #00B050;
    color: white;
}

QPushButton[class="primary"] {
    background-color: #00B050;
    color: white;
    border-color: #00B050;
}

QPushButton[class="danger"] {
    background-color: #FF4444;
    color: white;
    border-color: #FF4444;
}

QGroupBox {
    background-color: #FFFFFF;
    border: 1px solid #D0D0D0;
    border-radius: 6px;
    margin-top: 12px;
    padding: 12px;
    padding-top: 24px;
    font-weight: bold;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: #007A3D;
}

QTableWidget, QTableView {
    background-color: #FFFFFF;
    alternate-background-color: #F5F5F5;
    color: #1A1A2E;
    gridline-color: #E0E0E0;
    border: 1px solid #D0D0D0;
    selection-background-color: #00B050;
    selection-color: white;
}

QHeaderView::section {
    background-color: #E8E8E8;
    color: #007A3D;
    padding: 6px;
    border: 1px solid #D0D0D0;
    font-weight: bold;
}

QTextEdit, QPlainTextEdit {
    background-color: #FFFFFF;
    color: #1A1A2E;
    border: 1px solid #D0D0D0;
    border-radius: 4px;
    font-family: "Consolas", monospace;
    font-size: 12px;
}

QLineEdit {
    background-color: #FFFFFF;
    color: #1A1A2E;
    border: 1px solid #D0D0D0;
    border-radius: 4px;
    padding: 4px 8px;
}

QLineEdit:focus {
    border-color: #00B050;
}

QComboBox {
    background-color: #FFFFFF;
    color: #1A1A2E;
    border: 1px solid #D0D0D0;
    border-radius: 4px;
    padding: 4px 8px;
}

QProgressBar {
    background-color: #E0E0E0;
    border: 1px solid #D0D0D0;
    border-radius: 6px;
    text-align: center;
}

QProgressBar::chunk {
    background-color: #00B050;
    border-radius: 5px;
}

QStatusBar {
    background-color: #E8E8E8;
    color: #666666;
    border-top: 1px solid #D0D0D0;
}
"""


def apply_dark_theme(app):
    app.setStyleSheet(DARK_STYLE)


def apply_light_theme(app):
    app.setStyleSheet(LIGHT_STYLE)
