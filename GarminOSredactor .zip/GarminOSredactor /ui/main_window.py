#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GarminOSredactor — Main Window.
Tabbed GUI: GUNP | Шрифт | Прошивка | Русификатор | Карты | Настройки
"""

from PyQt5.QtWidgets import (
    QMainWindow, QTabWidget, QStatusBar, QAction, QMenuBar,
    QFileDialog, QMessageBox, QLabel
)
from PyQt5.QtCore import Qt, QSize

from ui.tab_gunp import GunpTab
from ui.tab_font_editor import FontEditorTab
from ui.tab_flasher import FlasherTab
from ui.tab_russian import RussianTab
from ui.tab_map_loader import MapLoaderTab
from ui.tab_settings import SettingsTab
from ui.styles import apply_dark_theme, apply_light_theme


APP_TITLE = "GarminOSredactor — by bashgarminash"
APP_VERSION = "1.0"


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.setMinimumSize(QSize(1100, 700))
        self.resize(1280, 820)

        # State
        self.current_theme = 0  # 0=dark, 1=light

        # Build UI
        self._create_menu()
        self._create_tabs()
        self._create_statusbar()

        # Apply default theme
        apply_dark_theme(self)

    def _create_menu(self):
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("Файл")

        act_open = QAction("Открыть прошивку (.rgn)", self)
        act_open.setShortcut("Ctrl+O")
        act_open.triggered.connect(lambda: self.tabs.widget(0).btn_open.click())
        file_menu.addAction(act_open)

        act_save = QAction("Сохранить прошивку", self)
        act_save.setShortcut("Ctrl+S")
        act_save.triggered.connect(self._save_firmware)
        file_menu.addAction(act_save)

        file_menu.addSeparator()

        act_exit = QAction("Выход", self)
        act_exit.setShortcut("Ctrl+Q")
        act_exit.triggered.connect(self.close)
        file_menu.addAction(act_exit)

        # Tools menu
        tools_menu = menubar.addMenu("Инструменты")

        act_extract = QAction("Экспорт всех языков", self)
        act_extract.triggered.connect(
            lambda: self.tabs.widget(0).btn_export_all.click() if self.tabs.widget(0).firmware else None
        )
        tools_menu.addAction(act_extract)

        act_compare = QAction("Сравнить прошивки", self)
        act_compare.triggered.connect(
            lambda: self.tabs.widget(0).btn_compare.click() if self.tabs.widget(0).firmware else None
        )
        tools_menu.addAction(act_compare)

        # Help menu
        help_menu = menubar.addMenu("Справка")

        act_about = QAction("О программе", self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    def _create_tabs(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Short tab names so nothing gets cut off
        tab_config = [
            ("GUNP", GunpTab),
            ("Шрифт", FontEditorTab),
            ("Прошивка", FlasherTab),
            ("Русификатор", RussianTab),
            ("Карты", MapLoaderTab),
            ("Настройки", SettingsTab),
        ]

        for i, (title, widget_class) in enumerate(tab_config):
            widget = widget_class(self)
            self.tabs.addTab(widget, title)

        # Connect settings theme callback
        settings_tab = self.tabs.widget(5)
        settings_tab.set_theme_callback(self._change_theme)

        # Tab change -> update status bar
        self.tabs.currentChanged.connect(self._on_tab_changed)

    def _create_statusbar(self):
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self.statusbar.showMessage("Готово")

    def _on_tab_changed(self, index):
        tab_names = [
            "GUNP — Анализатор прошивок",
            "Шрифт — Редактор шрифтов Garmin",
            "Прошивка — Прошивальщик Garmin",
            "Русификатор — Перевод прошивок",
            "Карты — Загрузчик карт",
            "Настройки"
        ]
        if 0 <= index < len(tab_names):
            self.statusbar.showMessage(tab_names[index])

    def _change_theme(self, theme_index):
        self.current_theme = theme_index
        if theme_index == 0:
            apply_dark_theme(self)
        else:
            apply_light_theme(self)
        self.statusbar.showMessage(
            "Тема: Тёмная" if theme_index == 0 else "Тема: Светлая"
        )

    def _save_firmware(self):
        for i in range(self.tabs.count()):
            w = self.tabs.widget(i)
            if hasattr(w, 'firmware') and w.firmware:
                from PyQt5.QtWidgets import QFileDialog
                path, _ = QFileDialog.getSaveFileName(
                    self, "Сохранить прошивку",
                    w.firmware.filename,
                    "RGN Firmware (*.rgn);;Все файлы (*.*)"
                )
                if path:
                    try:
                        w.firmware.save(path)
                        self.statusbar.showMessage(f"Сохранено: {path}")
                    except Exception as e:
                        QMessageBox.critical(self, "Ошибка", str(e))
                return
        QMessageBox.information(self, "Инфо", "Нет загруженной прошивки для сохранения")

    def _show_about(self):
        QMessageBox.about(
            self, "О программе",
            f"<h2>GarminOSredactor</h2>"
            f"<p><b>v{APP_VERSION}</b> — by bashgarminash</p>"
            f"<p>Полный набор инструментов для Garmin GPSMAP 60/70 series</p>"
            f"<br>"
            f"<p><b>Модули:</b></p>"
            f"<ul>"
            f"<li>GUNP — анализатор/декомпилятор прошивок</li>"
            f"<li>Font Editor — редактор растровых шрифтов</li>"
            f"<li>Flasher — прошивальщик (SD + USB)</li>"
            f"<li>Русификатор — применение русских переводов</li>"
            f"<li>Map Loader — загрузчик карт</li>"
            f"</ul>"
            f"<br>"
            f"<p><b>Поддержка:</b> GPSMAP 60Cx/60CSx/76Cx/76CSx</p>"
            f"<p><b>Кредиты:</b> @dfaefagt1-ak / Soviet Union</p>"
        )

    def closeEvent(self, event):
        event.accept()
