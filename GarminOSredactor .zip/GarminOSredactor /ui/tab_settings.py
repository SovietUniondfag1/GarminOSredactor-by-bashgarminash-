#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Settings Tab — theme, language, advanced options.
Advanced settings are hidden behind a button.
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton,
    QLabel, QComboBox, QLineEdit, QFileDialog, QMessageBox,
    QFrame, QScrollArea, QSizePolicy
)
from PyQt5.QtCore import Qt, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont


class SettingsTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._on_theme_change = None
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # ── Title ──
        title = QLabel("GarminOSredactor")
        title.setFont(QFont("Segoe UI", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00B050; border: none;")
        layout.addWidget(title)

        subtitle = QLabel("by bashgarminash")
        subtitle.setFont(QFont("Segoe UI", 14))
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color: #808090; border: none;")
        layout.addWidget(subtitle)

        desc = QLabel(
            "Полный набор инструментов для редактирования прошивок Garmin\n"
            "GPSMAP 60/70 series"
        )
        desc.setFont(QFont("Segoe UI", 11))
        desc.setAlignment(Qt.AlignCenter)
        desc.setStyleSheet("color: #A0A0B0; margin: 8px 0px; border: none;")
        layout.addWidget(desc)

        # ── Appearance ──
        appearance = QGroupBox("Внешний вид")
        app_layout = QVBoxLayout(appearance)
        app_layout.setSpacing(10)

        theme_row = QHBoxLayout()
        theme_row.setSpacing(12)
        lbl_theme = QLabel("Тема:")
        lbl_theme.setMinimumWidth(160)
        lbl_theme.setStyleSheet("border: none;")
        self.cmb_theme = QComboBox()
        self.cmb_theme.addItems(["Тёмная", "Светлая"])
        self.cmb_theme.setMinimumWidth(200)
        theme_row.addWidget(lbl_theme)
        theme_row.addWidget(self.cmb_theme)
        theme_row.addStretch()
        app_layout.addLayout(theme_row)

        lang_row = QHBoxLayout()
        lang_row.setSpacing(12)
        lbl_lang = QLabel("Язык интерфейса:")
        lbl_lang.setMinimumWidth(160)
        lbl_lang.setStyleSheet("border: none;")
        self.cmb_lang = QComboBox()
        self.cmb_lang.addItems(["Русский", "English"])
        self.cmb_lang.setCurrentIndex(0)
        self.cmb_lang.setMinimumWidth(200)
        lang_row.addWidget(lbl_lang)
        lang_row.addWidget(self.cmb_lang)
        lang_row.addStretch()
        app_layout.addLayout(lang_row)

        self.btn_apply_theme = QPushButton("Применить тему")
        self.btn_apply_theme.clicked.connect(self._apply_theme)
        app_layout.addWidget(self.btn_apply_theme)

        layout.addWidget(appearance)

        # ── Advanced toggle button ──
        self.btn_advanced = QPushButton("Расширенные настройки")
        self.btn_advanced.setCheckable(True)
        self.btn_advanced.setStyleSheet("""
            QPushButton {
                text-align: left;
                padding: 10px 16px;
                font-size: 14px;
                font-weight: bold;
                border: 1px solid #3D3D4D;
                border-radius: 6px;
                background-color: #2D2D3D;
            }
            QPushButton:checked {
                background-color: #1A3A2A;
                border-color: #00B050;
            }
            QPushButton:hover {
                border-color: #00B050;
            }
        """)
        self.btn_advanced.clicked.connect(self._toggle_advanced)
        layout.addWidget(self.btn_advanced)

        # ── Advanced container (hidden by default) ──
        self.advanced_container = QWidget()
        adv_layout = QVBoxLayout(self.advanced_container)
        adv_layout.setContentsMargins(0, 0, 0, 0)
        adv_layout.setSpacing(12)

        # --- Default Folders ---
        dirs = QGroupBox("Папки по умолчанию")
        dirs_layout = QVBoxLayout(dirs)
        dirs_layout.setSpacing(10)

        for label_text, attr_name, hint in [
            ("Прошивки (.rgn):", "le_fw", "Папка с прошивками Garmin"),
            ("Переводы (.bin):", "le_tr", "Папка с файлами перевода"),
            ("Карты (.img):", "le_maps", "Папка с картами Garmin"),
            ("Шрифты (.bin):", "le_fonts", "Папка со шрифтами"),
        ]:
            row = QHBoxLayout()
            row.setSpacing(12)
            lbl = QLabel(label_text)
            lbl.setMinimumWidth(160)
            lbl.setStyleSheet("border: none;")
            row.addWidget(lbl)
            le = QLineEdit()
            le.setPlaceholderText(hint)
            le.setMinimumWidth(250)
            le.setMinimumHeight(28)
            setattr(self, attr_name, le)
            row.addWidget(le)
            btn = QPushButton("...")
            btn.setFixedSize(40, 28)
            row.addWidget(btn)
            dirs_layout.addLayout(row)

        adv_layout.addWidget(dirs)

        # --- About ---
        about = QGroupBox("О программе")
        about_layout = QVBoxLayout(about)
        about_layout.setSpacing(4)

        info_text = (
            "<b>GarminOSredactor</b> v1.0<br>"
            "Полный набор инструментов для Garmin GPSMAP 60/70 series<br><br>"
            "<b>Модули:</b><br>"
            "&bull; <b>GUNP</b> — анализатор и декомпилятор прошивок .RGN<br>"
            "&bull; <b>Font Editor</b> — редактор растровых шрифтов Garmin<br>"
            "&bull; <b>Flasher</b> — прошивальщик (SD-карта + USB)<br>"
            "&bull; <b>Русификатор</b> — применение русских переводов<br>"
            "&bull; <b>Map Loader</b> — загрузчик карт (.img)<br><br>"
            "<b>Поддерживаемые устройства:</b><br>"
            "GPSMAP 60Cx, 60CSx, 60C, 60CS<br>"
            "GPSMAP 76Cx, 76CSx, 76C, 76CS<br><br>"
            "<b>Кредиты:</b><br>"
            "Разработка: @dfaefagt1-ak / Soviet Union<br>"
            "Проект: bashgarminash<br>"
            "Flawia team — оригинальные кириллические шрифты (2004)<br><br>"
            "<b>Лицензия:</b> Открытый исходный код"
        )
        lbl_about = QLabel(info_text)
        lbl_about.setWordWrap(True)
        lbl_about.setTextFormat(Qt.RichText)
        lbl_about.setStyleSheet("border: none; padding: 4px;")
        about_layout.addWidget(lbl_about)
        adv_layout.addWidget(about)

        layout.addWidget(self.advanced_container)
        self.advanced_container.setVisible(False)

        # ── Check updates ──
        self.btn_updates = QPushButton("Проверить обновления")
        self.btn_updates.clicked.connect(
            lambda: QMessageBox.information(
                self, "Обновления",
                "Вы используете последнюю версию.\n"
                "Проверяйте обновления на GitHub."
            )
        )
        layout.addWidget(self.btn_updates)

        layout.addStretch()

    def _toggle_advanced(self):
        visible = self.btn_advanced.isChecked()
        self.advanced_container.setVisible(visible)
        if visible:
            self.btn_advanced.setText("Расширенные настройки  [свернуть]")
        else:
            self.btn_advanced.setText("Расширенные настройки")

    def set_theme_callback(self, callback):
        self._on_theme_change = callback

    def _apply_theme(self):
        theme_idx = self.cmb_theme.currentIndex()
        if self._on_theme_change:
            self._on_theme_change(theme_idx)

    def get_theme_index(self):
        return self.cmb_theme.currentIndex()
