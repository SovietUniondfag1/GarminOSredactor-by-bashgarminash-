#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Russian Localizer Tab — apply Russian translations to Garmin firmware.
Load firmware + translation file, map strings, patch, export.
"""

import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton,
    QLabel, QFileDialog, QMessageBox, QTextEdit, QTableWidget,
    QTableWidgetItem, QHeaderView, QProgressBar, QComboBox,
    QCheckBox, QLineEdit, QSplitter
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont

from core.firmware_parser import FirmwareFile


class PatchThread(QThread):
    done = pyqtSignal(bool, str)
    log = pyqtSignal(str)

    def __init__(self, fw, lang_index, translation_data, credits_text=''):
        super().__init__()
        self.fw = fw
        self.lang_index = lang_index
        self.translation_data = translation_data
        self.credits_text = credits_text

    def run(self):
        try:
            sec = self.fw.get_language_by_index(self.lang_index)
            if not sec:
                self.done.emit(False, "Язык не найден")
                return

            # Add credits if provided
            data = self.translation_data
            if self.credits_text:
                data = data + b'\x0a\x0a' + self.credits_text.encode('windows-1251', errors='replace')

            old_size = sec.size
            new_size = len(data)

            self.log.emit(f"Старый размер: {old_size:,} байт")
            self.log.emit(f"Новый размер: {new_size:,} байт")
            self.log.emit(f"Разница: {new_size - old_size:+,} байт")
            self.log.emit(f"Лимит секции: {old_size:,} байт")

            if new_size > old_size:
                self.done.emit(False,
                    f"Перевод СЛИШКОМ БОЛЬШОЙ!\n"
                    f"Нужно: {new_size:,} байт\n"
                    f"Лимит: {old_size:,} байт\n"
                    f"Превышение: {new_size - old_size:,} байт")
                return

            padding = old_size - new_size
            self.log.emit(f"Остаток (padding): {padding:,} байт")
            self.log.emit("Применение перевода...")

            success = self.fw.replace_language_data(self.lang_index, data)
            if success:
                self.log.emit("✓ Перевод применён!")
                self.done.emit(True, f"Готово! Остаток: {padding:,} байт")
            else:
                self.done.emit(False, "Ошибка замены данных")
        except Exception as e:
            self.done.emit(False, str(e))


class RussianTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.firmware = None
        self.translation_data = None
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        # Toolbar
        toolbar = QHBoxLayout()

        self.btn_load_fw = QPushButton("📂 Открыть прошивку (.rgn)")
        self.btn_load_fw.setProperty("class", "primary")
        self.btn_load_fw.clicked.connect(self._load_firmware)
        toolbar.addWidget(self.btn_load_fw)

        self.btn_load_tr = QPushButton("🌐 Загрузить перевод (.bin)")
        self.btn_load_tr.clicked.connect(self._load_translation)
        self.btn_load_tr.setEnabled(False)
        toolbar.addWidget(self.btn_load_tr)

        self.btn_apply = QPushButton("✅ Применить перевод")
        self.btn_apply.setProperty("class", "primary")
        self.btn_apply.clicked.connect(self._apply_translation)
        self.btn_apply.setEnabled(False)
        toolbar.addWidget(self.btn_apply)

        self.btn_export = QPushButton("💾 Сохранить прошивку")
        self.btn_export.clicked.connect(self._export_firmware)
        self.btn_export.setEnabled(False)
        toolbar.addWidget(self.btn_export)

        toolbar.addStretch()
        self.lbl_status = QLabel("Готов")
        toolbar.addWidget(self.lbl_status)
        layout.addLayout(toolbar)

        # Info row
        info_row = QHBoxLayout()

        fw_group = QGroupBox("Прошивка")
        fw_l = QVBoxLayout(fw_group)
        self.lbl_fw_info = QLabel("Не загружена")
        self.lbl_fw_info.setFont(QFont("Consolas", 10))
        self.lbl_fw_info.setWordWrap(True)
        fw_l.addWidget(self.lbl_fw_info)
        fw_group.setMaximumWidth(450)
        info_row.addWidget(fw_group)

        tr_group = QGroupBox("Перевод")
        tr_l = QVBoxLayout(tr_group)
        self.lbl_tr_info = QLabel("Не загружен")
        self.lbl_tr_info.setFont(QFont("Consolas", 10))
        self.lbl_tr_info.setWordWrap(True)
        tr_l.addWidget(self.lbl_tr_info)
        info_row.addWidget(tr_group)

        size_group = QGroupBox("Бюджет размеров")
        size_l = QVBoxLayout(size_group)
        self.lbl_size_info = QLabel("—")
        self.lbl_size_info.setFont(QFont("Consolas", 10))
        self.lbl_size_info.setWordWrap(True)
        size_l.addWidget(self.lbl_size_info)
        info_row.addWidget(size_group)

        layout.addLayout(info_row)

        # Credits (locked — cannot be removed)
        cred_row = QHBoxLayout()
        self.chk_credits = QCheckBox("Кредиты (обязательно)")
        self.chk_credits.setChecked(True)
        self.chk_credits.setEnabled(False)
        self.chk_credits.setToolTip("Копирайт включён обязательно и не может быть убран")
        self.chk_credits.setStyleSheet(
            "QCheckBox::indicator:unchecked { border: 1px solid #555; background: #333; }"
            "QCheckBox::indicator:checked { border: 1px solid #00B050; background: #00B050; }"
        )
        cred_row.addWidget(self.chk_credits)
        self.txt_credits = QLineEdit(
            "Translation: (c)2025 @dfaefagt1-ak / Soviet Union for bashgarminash project"
        )
        self.txt_credits.setEnabled(False)
        cred_row.addWidget(self.txt_credits)
        layout.addLayout(cred_row)

        # Target language selector
        lang_row = QHBoxLayout()
        lang_row.addWidget(QLabel("Целевой язык (замена):"))
        self.cmb_target_lang = QComboBox()
        lang_row.addWidget(self.cmb_target_lang)
        lang_row.addWidget(QLabel("Кодировка перевода:"))
        self.cmb_encoding = QComboBox()
        self.cmb_encoding.addItems(['Windows-1251', 'UTF-8', 'CP437'])
        self.cmb_encoding.setCurrentIndex(0)
        lang_row.addWidget(self.cmb_encoding)
        lang_row.addStretch()
        layout.addLayout(lang_row)

        # Splitter: table + log
        splitter = QSplitter(Qt.Vertical)

        # String mapping table
        tbl_group = QGroupBox("Таблица соответствия (Английский → Русский)")
        tbl_l = QVBoxLayout(tbl_group)
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["#", "English (оригинал)", "Russian (перевод)"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        tbl_l.addWidget(self.table)
        splitter.addWidget(tbl_group)

        # Log
        log_group = QGroupBox("Журнал")
        log_l = QVBoxLayout(log_group)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setFont(QFont("Consolas", 10))
        self.txt_log.setMaximumHeight(150)
        log_l.addWidget(self.txt_log)
        splitter.addWidget(log_group)

        splitter.setSizes([400, 150])
        layout.addWidget(splitter)

        # Progress
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

    def _log(self, msg):
        self.txt_log.append(msg)

    def _load_firmware(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Открыть прошивку", "",
            "RGN Firmware (*.rgn);;Все файлы (*.*)"
        )
        if not path:
            return
        try:
            self.firmware = FirmwareFile.load(path)
            self.btn_load_tr.setEnabled(True)
            self.btn_apply.setEnabled(True)
            self.lbl_fw_info.setText(
                f"Файл: {self.firmware.filename}\n"
                f"Размер: {self.firmware.file_size:,} байт\n"
                f"Языков: {len(self.firmware.languages)}\n"
                f"Сигнатура: {self.firmware.header.signature_ascii}"
            )
            self.cmb_target_lang.clear()
            for i, sec in enumerate(self.firmware.languages):
                self.cmb_target_lang.addItem(f"{i+1}. {sec.name}", i)
            self._log(f"✓ Загружена: {self.firmware.filename}")
            self._update_size_info()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _load_translation(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Загрузить файл перевода", "",
            "Translation (*.bin);;Все файлы (*.*)"
        )
        if not path:
            return
        try:
            with open(path, 'rb') as f:
                self.translation_data = f.read()
            enc = self.cmb_encoding.currentText().lower().replace('-', '')
            if enc == 'windows1251':
                enc = 'cp1251'

            strings = self.translation_data.split(b'\x00')
            non_empty = [s for s in strings if len(s) > 0]

            self.lbl_tr_info.setText(
                f"Файл: {os.path.basename(path)}\n"
                f"Размер: {len(self.translation_data):,} байт\n"
                f"Строк: {len(non_empty)}\n"
                f"Кодировка: {self.cmb_encoding.currentText()}"
            )
            self._log(f"✓ Перевод загружен: {len(non_empty)} строк")
            self._fill_table()
            self._update_size_info()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _fill_table(self):
        if not self.firmware or not self.translation_data:
            return

        idx = self.cmb_target_lang.currentData()
        if idx is None:
            return

        sec = self.firmware.get_language_by_index(idx)
        if not sec:
            return

        enc_tr = self.cmb_encoding.currentText().lower().replace('-', '')
        if enc_tr == 'windows1251':
            enc_tr = 'cp1251'

        orig_strings = sec.strings
        tr_strings = [s for s in self.translation_data.split(b'\x00') if len(s) > 0]

        count = min(len(orig_strings), len(tr_strings))
        self.table.setRowCount(count)

        for i in range(count):
            self.table.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            try:
                en = orig_strings[i].decode('utf-8', errors='replace')
            except Exception:
                en = repr(orig_strings[i])
            try:
                ru = tr_strings[i].decode(enc_tr, errors='replace')
            except Exception:
                ru = repr(tr_strings[i])
            if len(en) > 100:
                en = en[:97] + "..."
            if len(ru) > 100:
                ru = ru[:97] + "..."

            self.table.setItem(i, 1, QTableWidgetItem(en))
            self.table.setItem(i, 2, QTableWidgetItem(ru))

        # Color mismatched sizes
        if len(orig_strings) != len(tr_strings):
            self.lbl_size_info.setStyleSheet("color: #FF6B35;")
            self._log(f"⚠ Количество строк не совпадает: "
                      f"прошивка={len(orig_strings)}, перевод={len(tr_strings)}")
        self._log(f"Таблица: {count} строк")

    def _update_size_info(self):
        if not self.firmware or not self.translation_data:
            self.lbl_size_info.setText("—")
            return

        idx = self.cmb_target_lang.currentData()
        if idx is None:
            return
        sec = self.firmware.get_language_by_index(idx)
        if not sec:
            return

        tr_size = len(self.translation_data)
        limit = sec.size
        avail = limit - tr_size

        color = "#00B050" if avail > 0 else "#FF4444"
        self.lbl_size_info.setStyleSheet(f"color: {color};")
        self.lbl_size_info.setText(
            f"Размер перевода: {tr_size:,} байт\n"
            f"Лимит секции: {limit:,} байт\n"
            f"{'✓' if avail > 0 else '✗'} {'Свободно' if avail > 0 else 'Превышение'}: {avail:+,} байт"
        )

    def _apply_translation(self):
        if not self.firmware or not self.translation_data:
            QMessageBox.warning(self, "Внимание", "Загрузите прошивку и перевод")
            return

        idx = self.cmb_target_lang.currentData()
        if idx is None:
            QMessageBox.warning(self, "Внимание", "Выберите целевой язык")
            return

        credits = self.txt_credits.text() if self.chk_credits.isChecked() else ''

        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.btn_apply.setEnabled(False)

        self._thread = PatchThread(self.firmware, idx, self.translation_data, credits)
        self._thread.log.connect(self._log)
        self._thread.done.connect(self._on_patched)
        self._thread.start()

    def _on_patched(self, success, msg):
        self.progress.setVisible(False)
        self.btn_apply.setEnabled(True)
        if success:
            self.lbl_status.setText("✓ Перевод применён")
            self.lbl_status.setStyleSheet("color: #00B050;")
            self.btn_export.setEnabled(True)
            QMessageBox.information(self, "Готово", msg)
        else:
            self.lbl_status.setText("✗ Ошибка")
            self.lbl_status.setStyleSheet("color: #FF4444;")
            QMessageBox.critical(self, "Ошибка", msg)

    def _export_firmware(self):
        if not self.firmware:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить прошивку",
            self.firmware.filename.replace('.rgn', '_rus.rgn'),
            "RGN Firmware (*.rgn);;Все файлы (*.*)"
        )
        if path:
            self.firmware.save(path)
            self._log(f"✓ Сохранено: {path}")
            self.lbl_status.setText(f"✓ Сохранено: {os.path.basename(path)}")
            QMessageBox.information(self, "Готово",
                                    f"Прошивка сохранена:\n{path}\n\n"
                                    "Для прошивки:\n"
                                    "1. Скопируйте на SD-карту (FAT32)\n"
                                    "2. Вставьте в Garmin\n"
                                    "3. Удерживайте PAGE + POWER")
