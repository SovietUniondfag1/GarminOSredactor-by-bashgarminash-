#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Font Editor Tab — view and edit Garmin bitmap fonts (Flawia/GUNP format).
Loads .bin font files, displays glyph grid, pixel editor, import from firmware.
"""

import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton,
    QLabel, QFileDialog, QMessageBox, QComboBox,
    QGridLayout, QScrollArea, QSizePolicy, QSpinBox
)
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QFont, QImage, QPixmap, QColor, QPainter

from core.font_engine import GarminFont, Glyph, find_fonts_in_firmware


def qRgb(r, g, b):
    return (r << 16) | (g << 8) | b


class GlyphWidget(QWidget):
    """Single glyph display widget — clickable pixel grid."""

    def __init__(self, glyph=None, scale=1, parent=None):
        super().__init__(parent)
        self.glyph = glyph
        self.scale = scale
        self.selected = False
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

    def set_glyph(self, glyph):
        self.glyph = glyph
        self.update()

    def set_selected(self, val):
        self.selected = val
        self.update()

    def sizeHint(self):
        if self.glyph:
            return QSize(self.glyph.width * self.scale + 4,
                         self.glyph.height * self.scale + 4)
        return QSize(20, 20)

    def paintEvent(self, event):
        if not self.glyph:
            return
        p = QPainter(self)
        s = self.scale
        w, h = self.glyph.width, self.glyph.height
        ox, oy = 2, 2

        bg = QColor("#1A4A2A") if self.selected else QColor("#2D2D3D")
        p.fillRect(0, 0, w * s + 4, h * s + 4, bg)

        for row in range(h):
            for col in range(w):
                x, y = ox + col * s, oy + row * s
                if self.glyph.get_pixel(row, col):
                    p.fillRect(x, y, s, s, QColor("#00B050"))
                else:
                    p.fillRect(x, y, s, s, QColor("#1E1E2E"))

        if self.selected:
            p.setPen(QColor("#00FF70"))
            p.setBrush(Qt.NoBrush)
            p.drawRect(0, 0, w * s + 3, h * s + 3)
        p.end()


class GlyphEditorWidget(QWidget):
    """Large pixel editor for a single glyph."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.glyph = None
        self.pixel_scale = 16
        self._on_toggle = None
        self.setMinimumSize(150, 150)

    def set_glyph(self, glyph, on_toggle=None):
        self.glyph = glyph
        self._on_toggle = on_toggle
        if glyph:
            w = max(glyph.width * self.pixel_scale + 4, 150)
            h = max(glyph.height * self.pixel_scale + 4, 150)
            self.setMinimumSize(w, h)
        self.update()

    def paintEvent(self, event):
        if not self.glyph:
            return
        p = QPainter(self)
        s = self.pixel_scale
        w, h = self.glyph.width, self.glyph.height
        ox, oy = 2, 2
        p.fillRect(0, 0, w * s + 4, h * s + 4, QColor("#1E1E2E"))

        for row in range(h):
            for col in range(w):
                x, y = ox + col * s, oy + row * s
                if self.glyph.get_pixel(row, col):
                    p.fillRect(x, y, s, s, QColor("#00B050"))
                else:
                    p.fillRect(x, y, s, s, QColor("#252535"))

        p.setPen(QColor("#3D3D4D"))
        for row in range(h + 1):
            p.drawLine(ox, oy + row * s, ox + w * s, oy + row * s)
        for col in range(w + 1):
            p.drawLine(ox + col * s, oy, ox + col * s, oy + h * s)
        p.end()

    def mousePressEvent(self, event):
        if not self.glyph or not self._on_toggle:
            return
        col = (event.x() - 2) // self.pixel_scale
        row = (event.y() - 2) // self.pixel_scale
        if 0 <= row < self.glyph.height and 0 <= col < self.glyph.width:
            self.glyph.toggle_pixel(row, col)
            self.update()
            if self._on_toggle:
                self._on_toggle()


class FontEditorTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.font = None
        self.selected_idx = -1
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        # Toolbar
        tb = QHBoxLayout()
        self.btn_load = QPushButton("Открыть шрифт (.bin)")
        self.btn_load.setProperty("class", "primary")
        self.btn_load.clicked.connect(self._load_font)
        tb.addWidget(self.btn_load)

        self.btn_import_fw = QPushButton("Импорт из прошивки (.rgn)")
        self.btn_import_fw.clicked.connect(self._import_from_firmware)
        tb.addWidget(self.btn_import_fw)

        self.btn_save = QPushButton("Сохранить шрифт")
        self.btn_save.clicked.connect(self._save_font)
        self.btn_save.setEnabled(False)
        tb.addWidget(self.btn_save)

        self.btn_clear = QPushButton("Очистить глиф")
        self.btn_clear.clicked.connect(self._clear_glyph)
        self.btn_clear.setEnabled(False)
        tb.addWidget(self.btn_clear)

        self.btn_invert = QPushButton("Инвертировать")
        self.btn_invert.clicked.connect(self._invert_glyph)
        self.btn_invert.setEnabled(False)
        tb.addWidget(self.btn_invert)

        tb.addStretch()
        self.lbl_info = QLabel("Шрифт не загружен")
        self.lbl_info.setStyleSheet("color: #808090;")
        tb.addWidget(self.lbl_info)
        layout.addLayout(tb)

        # Font selector row
        sel = QHBoxLayout()
        sel.addWidget(QLabel("Шрифт:"))
        self.cmb_font = QComboBox()
        self.cmb_font.setMinimumWidth(200)
        sel.addWidget(self.cmb_font)

        sel.addWidget(QLabel("Символ:"))
        self.spn_char = QSpinBox()
        self.spn_char.setRange(0, 65535)
        self.spn_char.setValue(32)
        self.spn_char.valueChanged.connect(self._goto_char)
        sel.addWidget(self.spn_char)

        sel.addWidget(QLabel("Масштаб:"))
        self.cmb_scale = QComboBox()
        self.cmb_scale.addItems(["2x", "4x", "6x", "8x"])
        self.cmb_scale.setCurrentIndex(1)
        self.cmb_scale.currentIndexChanged.connect(self._rebuild_grid)
        sel.addWidget(self.cmb_scale)

        sel.addStretch()
        layout.addLayout(sel)

        # Splitter
        from PyQt5.QtWidgets import QSplitter
        splitter = QSplitter(Qt.Vertical)

        # Glyph grid
        grid_grp = QGroupBox("Таблица глифов")
        gl = QVBoxLayout(grid_grp)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.grid_w = QWidget()
        self.grid_layout = QGridLayout(self.grid_w)
        self.grid_layout.setSpacing(2)
        self.scroll.setWidget(self.grid_w)
        gl.addWidget(self.scroll)
        splitter.addWidget(grid_grp)

        # Editor + info
        ed_grp = QGroupBox("Редактор глифа")
        ed_l = QHBoxLayout(ed_grp)
        self.editor = GlyphEditorWidget()
        self.editor._on_toggle = self._on_pixel_edited
        ed_l.addWidget(self.editor, stretch=1)

        info_l = QVBoxLayout()
        self.lbl_glyph = QLabel("Выберите глиф")
        self.lbl_glyph.setFont(QFont("Consolas", 10))
        self.lbl_glyph.setWordWrap(True)
        info_l.addWidget(self.lbl_glyph)

        self.preview = QLabel()
        self.preview.setMinimumSize(80, 80)
        self.preview.setAlignment(Qt.AlignCenter)
        info_l.addWidget(self.preview)
        info_l.addStretch()
        ed_l.addLayout(info_l, stretch=0)
        splitter.addWidget(ed_grp)

        splitter.setSizes([350, 250])
        layout.addWidget(splitter)

    def _log(self, msg):
        self.lbl_info.setText(msg)

    def _get_scale(self):
        return [2, 4, 6, 8][self.cmb_scale.currentIndex()]

    def _load_font(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Открыть шрифт Garmin", "",
            "Font files (*.bin);;Все файлы (*.*)"
        )
        if not path:
            return
        try:
            self.font = GarminFont.load(path)
            self._on_font_loaded(os.path.basename(path))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить:\n{e}")

    def _import_from_firmware(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Выберите прошивку (.rgn)", "",
            "RGN Firmware (*.rgn);;Все файлы (*.*)"
        )
        if not path:
            return
        try:
            with open(path, 'rb') as f:
                fw_data = f.read()

            found = find_fonts_in_firmware(fw_data)
            if not found:
                QMessageBox.information(self, "Шрифты",
                    "Шрифты в формате Garmin не найдены в этой прошивке.")
                return

            self.cmb_font.clear()
            for i, fi in enumerate(found):
                label = (f"Шрифт {i+1}: {fi['char_width']}x{fi['height']}px "
                         f"({fi['file_size']} байт, смещение {fi['offset']:#x})")
                self.cmb_font.addItem(label, fi)
            self.cmb_font.currentIndexChanged.connect(self._on_fw_font_selected)
            self._fw_data = fw_data
            self._log(f"Найдено шрифтов: {len(found)} в {os.path.basename(path)}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _on_fw_font_selected(self, idx):
        if idx < 0:
            return
        fi = self.cmb_font.currentData()
        if not fi:
            return
        try:
            off = fi['offset']
            size = fi['file_size']
            font_data = self._fw_data[off:off + size]
            self.font = GarminFont.from_bytes(font_data)
            name = f"font_{idx+1}_{fi['char_width']}x{fi['height']}"
            self._on_font_loaded(name)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить шрифт:\n{e}")

    def _on_font_loaded(self, name):
        self.btn_save.setEnabled(True)
        self._rebuild_grid()
        filled = self.font.get_filled_glyph_count()
        linked = self.font.get_linked_glyph_count()
        self._log(f"{name}: {self.font.glyph_count} глифов, "
                  f"{self.font.char_width}x{self.font.char_height}px, "
                  f"заполнено={filled}, связанных={linked}")

    def _rebuild_grid(self):
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        if not self.font:
            return

        scale = self._get_scale()
        cols = max(16, 256 // scale)
        self.glyph_widgets = []
        keys = sorted(self.font.glyphs.keys())

        for i, cc in enumerate(keys):
            glyph = self.font.glyphs[cc]
            gw = GlyphWidget(glyph, scale=scale)
            row_idx, col_idx = i // cols, i % cols
            self.grid_layout.addWidget(gw, row_idx, col_idx)
            self.glyph_widgets.append((cc, gw))

    def _goto_char(self, char_code):
        if not self.font:
            return
        glyph = self.font.get_glyph(char_code)
        if not glyph:
            glyph = self.font.create_empty_glyph(char_code)
            self.font.set_glyph(char_code, glyph)
            self._rebuild_grid()

        # Select in grid
        if 0 <= self.selected_idx < len(self.glyph_widgets):
            _, old_gw = self.glyph_widgets[self.selected_idx]
            old_gw.set_selected(False)

        for i, (cc, gw) in enumerate(self.glyph_widgets):
            if cc == char_code:
                self.selected_idx = i
                gw.set_selected(True)
                break

        self.editor.set_glyph(glyph, on_toggle=self._on_pixel_edited)
        self.btn_clear.setEnabled(True)
        self.btn_invert.setEnabled(True)
        self._update_glyph_info(char_code, glyph)

    def _update_glyph_info(self, cc, glyph):
        display = glyph.char
        filled = sum(1 for r in glyph.pixels for p in r if p)
        total = glyph.width * glyph.height
        self.lbl_glyph.setText(
            f"Символ: {display}\n"
            f"Код: {cc:#06x} ({cc})\n"
            f"Размер: {glyph.width}x{glyph.height}\n"
            f"Пикселей: {filled}/{total}\n"
            f"Пустой: {'Да' if glyph.is_empty else 'Нет'}"
        )
        img = QImage(glyph.width, glyph.height, QImage.Format_Mono)
        img.setColor(0, qRgb(30, 30, 46))
        img.setColor(1, qRgb(0, 176, 80))
        for r in range(glyph.height):
            for c in range(glyph.width):
                img.setPixel(c, r, 1 if glyph.get_pixel(r, c) else 0)
        pix = QPixmap.fromImage(img).scaled(
            80, 80, Qt.KeepAspectRatio, Qt.NearestNeighbor)
        self.preview.setPixmap(pix)

    def _on_pixel_edited(self):
        if self.font and 0 <= self.selected_idx < len(self.glyph_widgets):
            cc, gw = self.glyph_widgets[self.selected_idx]
            gw.set_glyph(self.editor.glyph)
            self._update_glyph_info(cc, self.editor.glyph)

    def _clear_glyph(self):
        if self.editor.glyph:
            self.editor.glyph.clear()
            self.editor.update()
            self._on_pixel_edited()

    def _invert_glyph(self):
        if self.editor.glyph:
            self.editor.glyph.invert()
            self.editor.update()
            self._on_pixel_edited()

    def _save_font(self):
        if not self.font:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить шрифт", "font.bin",
            "Font files (*.bin);;Все файлы (*.*)"
        )
        if path:
            try:
                self.font.save(path)
                QMessageBox.information(self, "Готово", f"Сохранено: {path}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))
