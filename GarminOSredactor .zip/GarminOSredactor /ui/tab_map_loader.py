#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Map Loader Tab — manage maps on Garmin devices.
Detect mass storage, list .img files, add/remove maps.
"""

import os
import shutil
import stat
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton,
    QLabel, QFileDialog, QMessageBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QProgressBar, QListWidget
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal

from core import flasher


IMG_HEADER_MAGIC = b'\x00\x00\x00\x00IMG'


def is_garmin_img(filepath):
    """Check if file looks like a Garmin .img map file."""
    try:
        size = os.path.getsize(filepath)
        if size < 128:
            return False
        with open(filepath, 'rb') as f:
            header = f.read(128)
        # Garmin IMG files have specific structure
        # Check for common Garmin IMG signatures
        if header[:4] == IMG_HEADER_MAGIC:
            return True
        # Many Garmin maps start with header containing "GARMIN" or have
        # specific byte patterns at known offsets
        if b'GARMIN' in header[:64]:
            return True
        # Check by extension and reasonable size
        if filepath.lower().endswith('.img') and size > 1024:
            return True
        return False
    except Exception:
        return False


def scan_maps(directory):
    """Scan directory for Garmin map (.img) files."""
    maps = []
    garmin_dir = os.path.join(directory, 'Garmin')
    scan_dirs = [directory]
    if os.path.isdir(garmin_dir):
        scan_dirs.append(garmin_dir)

    for scan_dir in scan_dirs:
        if not os.path.isdir(scan_dir):
            continue
        for fname in os.listdir(scan_dir):
            if fname.lower().endswith('.img'):
                fpath = os.path.join(scan_dir, fname)
                try:
                    size = os.path.getsize(fpath)
                    mtime = os.path.getmtime(fpath)
                    maps.append({
                        'name': fname,
                        'path': fpath,
                        'size': size,
                        'mtime': mtime,
                        'is_garmin': is_garmin_img(fpath),
                    })
                except OSError:
                    pass
    return maps


class CopyThread(QThread):
    progress = pyqtSignal(int, int)
    done = pyqtSignal(bool, str)
    log = pyqtSignal(str)

    def __init__(self, src, dst):
        super().__init__()
        self.src = src
        self.dst = dst

    def run(self):
        try:
            total = os.path.getsize(self.src)
            copied = 0
            self.log.emit(f"Копирование {os.path.basename(self.src)}...")
            with open(self.src, 'rb') as fin:
                with open(self.dst, 'wb') as fout:
                    while True:
                        chunk = fin.read(1024 * 1024)  # 1MB chunks
                        if not chunk:
                            break
                        fout.write(chunk)
                        copied += len(chunk)
                        self.progress.emit(copied, total)
            self.done.emit(True, f"Скопировано: {os.path.basename(self.dst)}")
        except Exception as e:
            self.done.emit(False, str(e))


class MapLoaderTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_maps = []
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        # Toolbar
        toolbar = QHBoxLayout()

        self.btn_detect = QPushButton("🔍 Обнаружить устройство")
        self.btn_detect.setProperty("class", "primary")
        self.btn_detect.clicked.connect(self._detect_device)
        toolbar.addWidget(self.btn_detect)

        self.btn_add = QPushButton("➕ Добавить карту (.img)")
        self.btn_add.clicked.connect(self._add_map)
        self.btn_add.setEnabled(False)
        toolbar.addWidget(self.btn_add)

        self.btn_remove = QPushButton("🗑 Удалить выбранную")
        self.btn_remove.setProperty("class", "danger")
        self.btn_remove.clicked.connect(self._remove_map)
        self.btn_remove.setEnabled(False)
        toolbar.addWidget(self.btn_remove)

        toolbar.addStretch()

        self.lbl_device = QLabel("Устройство не подключено")
        self.lbl_device.setStyleSheet("color: #FF6B35;")
        toolbar.addWidget(self.lbl_device)
        layout.addLayout(toolbar)

        # Info
        self.lbl_info = QLabel("")
        self.lbl_info.setFont(self.lbl_info.font())
        self.lbl_info.setWordWrap(True)
        layout.addWidget(self.lbl_info)

        # Maps table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels([
            "Имя файла", "Путь", "Размер", "Дата", "Garmin IMG"
        ])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.cellClicked.connect(self._on_row_clicked)
        layout.addWidget(self.table)

        # Progress
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        # Instructions
        instr = QLabel(
            "💡 Подсказка: Garmin устройства подключаются как USB-накопитель.\n"
            "Убедитесь что устройство включено и подключено к компьютеру.\n"
            "Карты (.img) обычно хранятся в папке /Garmin/ на устройстве."
        )
        instr.setStyleSheet("color: #808090; font-size: 11px;")
        instr.setWordWrap(True)
        layout.addWidget(instr)

    def _log(self, msg):
        self.lbl_info.setText(msg)

    def _detect_device(self):
        drives = flasher.get_removable_drives()
        if not drives:
            # Also check /media on Linux
            QMessageBox.information(
                self, "Обнаружение",
                "Съёмные диски не найдены.\n\n"
                "Подключите Garmin устройство кабелем USB.\n"
                "Устройство должно появиться как накопитель.\n\n"
                "Или выберите папку устройства вручную."
            )
            self._manual_select()
            return

        # Try to find Garmin folder on any drive
        for d in drives:
            garmin_path = os.path.join(d['path'], 'Garmin')
            if os.path.isdir(garmin_path):
                self._scan_device(d['path'])
                return

        # Let user pick
        self._manual_select()

    def _manual_select(self):
        path = QFileDialog.getExistingDirectory(
            self, "Выберите папку Garmin устройства",
            "/media" if os.name != 'nt' else ""
        )
        if path:
            self._scan_device(path)

    def _scan_device(self, device_path):
        self.device_path = device_path
        self.current_maps = scan_maps(device_path)
        self.lbl_device.setText(f"✓ {device_path}")
        self.lbl_device.setStyleSheet("color: #00B050;")
        self.btn_add.setEnabled(True)

        self.table.setRowCount(len(self.current_maps))
        for i, m in enumerate(self.current_maps):
            self.table.setItem(i, 0, QTableWidgetItem(m['name']))
            self.table.setItem(i, 1, QTableWidgetItem(m['path']))
            self.table.setItem(i, 2, QTableWidgetItem(f"{m['size']:,} байт"))
            from datetime import datetime
            dt = datetime.fromtimestamp(m['mtime']).strftime('%Y-%m-%d %H:%M')
            self.table.setItem(i, 3, QTableWidgetItem(dt))
            self.table.setItem(i, 4, QTableWidgetItem("✓" if m['is_garmin'] else "?"))

        total_size = sum(m['size'] for m in self.current_maps)
        self._log(f"Найдено карт: {len(self.current_maps)} | "
                  f"Общий размер: {total_size / 1024 / 1024:.1f} МБ")

        if self.current_maps:
            self.btn_remove.setEnabled(True)

    def _on_row_clicked(self, row, col):
        self.btn_remove.setEnabled(True)

    def _add_map(self):
        if not hasattr(self, 'device_path'):
            QMessageBox.warning(self, "Внимание", "Сначала выберите устройство")
            return

        files, _ = QFileDialog.getOpenFileNames(
            self, "Выберите файлы карт", "",
            "Garmin IMG (*.img);;Все файлы (*.*)"
        )
        if not files:
            return

        garmin_dir = os.path.join(self.device_path, 'Garmin')
        if not os.path.isdir(garmin_dir):
            try:
                os.makedirs(garmin_dir)
            except OSError:
                garmin_dir = self.device_path

        for f in files:
            dest = os.path.join(garmin_dir, os.path.basename(f))
            if os.path.exists(dest):
                reply = QMessageBox.question(
                    self, "Файл существует",
                    f"{os.path.basename(f)} уже существует.\nЗаменить?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply != QMessageBox.Yes:
                    continue

            self.progress.setVisible(True)
            self.progress.setRange(0, 100)

            self._copy_thread = CopyThread(f, dest)
            self._copy_thread.progress.connect(
                lambda cur, tot: self.progress.setValue(int(cur / tot * 100))
            )
            self._copy_thread.done.connect(self._on_copy_done)
            self._copy_thread.log.connect(self._log)
            self._copy_thread.start()

    def _on_copy_done(self, success, msg):
        self.progress.setVisible(False)
        if success:
            self._log(f"✓ {msg}")
        else:
            QMessageBox.critical(self, "Ошибка", msg)
        # Rescan
        if hasattr(self, 'device_path'):
            self._scan_device(self.device_path)

    def _remove_map(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Внимание", "Выберите карту для удаления")
            return

        if row >= len(self.current_maps):
            return

        m = self.current_maps[row]
        reply = QMessageBox.warning(
            self, "Удалить карту?",
            f"Удалить {m['name']}?\n\n"
            f"Размер: {m['size']:,} байт\n"
            f"Путь: {m['path']}",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            try:
                os.remove(m['path'])
                self._log(f"🗑 Удалена: {m['name']}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))

            if hasattr(self, 'device_path'):
                self._scan_device(self.device_path)
