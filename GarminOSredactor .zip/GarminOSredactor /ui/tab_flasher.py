#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Flasher Tab — firmware installer for Garmin devices.
SD card preparation + USB flash placeholder.
"""

import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton,
    QLabel, QFileDialog, QMessageBox, QTextEdit, QProgressBar,
    QComboBox, QListWidget, QListWidgetItem
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal

from core import flasher


class SdPrepareThread(QThread):
    progress = pyqtSignal(str)
    done = pyqtSignal(dict)

    def __init__(self, firmware_path, drive_path):
        super().__init__()
        self.firmware_path = firmware_path
        self.drive_path = drive_path

    def run(self):
        result = flasher.prepare_sd_card(
            self.firmware_path, self.drive_path,
            callback=lambda msg: self.progress.emit(msg)
        )
        self.done.emit(result)


class FlasherTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        # ── Title ──
        title = QLabel("⚡ Прошивальщик Garmin")
        title.setFont(title.font())
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #00B050;")
        layout.addWidget(title)

        # ── Two columns ──
        cols = QHBoxLayout()

        # ── Left: SD Card method ──
        sd_group = QGroupBox("💾 Прошивка через SD-карту")
        sd_layout = QVBoxLayout(sd_group)

        sd_layout.addWidget(QLabel("Файл прошивки (.rgn):"))
        self.lbl_fw_path = QLabel("Не выбран")
        self.lbl_fw_path.setWordWrap(True)
        sd_layout.addWidget(self.lbl_fw_path)

        btn_row = QHBoxLayout()
        self.btn_select_fw = QPushButton("Выбрать .rgn")
        self.btn_select_fw.setProperty("class", "primary")
        self.btn_select_fw.clicked.connect(self._select_firmware)
        btn_row.addWidget(self.btn_select_fw)
        sd_layout.addLayout(btn_row)

        sd_layout.addWidget(QLabel(""))
        sd_layout.addWidget(QLabel("SD-карта / накопитель:"))

        self.lst_drives = QListWidget()
        self.lst_drives.setMaximumHeight(120)
        sd_layout.addWidget(self.lst_drives)

        btn_row2 = QHBoxLayout()
        self.btn_refresh = QPushButton("🔄 Обновить")
        self.btn_refresh.clicked.connect(self._refresh_drives)
        btn_row2.addWidget(self.btn_refresh)

        self.btn_format = QPushButton("📐 Форматировать FAT32")
        self.btn_format.clicked.connect(self._format_drive)
        btn_row2.addWidget(self.btn_format)
        sd_layout.addLayout(btn_row2)

        self.btn_prepare_sd = QPushButton("📁 Подготовить SD-карту")
        self.btn_prepare_sd.setProperty("class", "primary")
        self.btn_prepare_sd.clicked.connect(self._prepare_sd)
        self.btn_prepare_sd.setEnabled(False)
        sd_layout.addWidget(self.btn_prepare_sd)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        sd_layout.addWidget(self.progress)

        cols.addWidget(sd_group)

        # ── Right: USB method ──
        usb_group = QGroupBox("🔌 Прошивка через USB")
        usb_layout = QVBoxLayout(usb_group)

        if flasher.check_pyserial():
            self.lbl_usb_status = QLabel("✓ pyserial установлен")
            self.lbl_usb_status.setStyleSheet("color: #00B050;")
        else:
            self.lbl_usb_status = QLabel("✗ pyserial НЕ установлен\n"
                                          "Для USB-прошивки установите:\n"
                                          "pip install pyserial")
            self.lbl_usb_status.setStyleSheet("color: #FF6B35;")
        usb_layout.addWidget(self.lbl_usb_status)

        usb_layout.addWidget(QLabel("Доступные порты:"))
        self.lst_ports = QListWidget()
        self.lst_ports.setMaximumHeight(100)
        ports = flasher.get_serial_ports()
        for p in ports:
            self.lst_ports.addItem(p)
        if not ports:
            self.lst_ports.addItem("Нет доступных портов")
        usb_layout.addWidget(self.lst_ports)

        self.btn_detect = QPushButton("🔍 Найти Garmin")
        self.btn_detect.clicked.connect(self._detect_garmin)
        usb_layout.addWidget(self.btn_detect)

        self.btn_usb_flash = QPushButton("⚡ Прошить через USB")
        self.btn_usb_flash.setProperty("class", "primary")
        self.btn_usb_flash.clicked.connect(self._usb_flash)
        self.btn_usb_flash.setEnabled(False)
        usb_layout.addWidget(self.btn_usb_flash)

        usb_layout.addStretch()
        usb_layout.addWidget(QLabel(
            "USB-прошивка работает через Garmin USB протокол.\n"
            "Устройство должно быть подключено и включено."
        ))
        cols.addWidget(usb_group)

        layout.addLayout(cols)

        # ── Log ──
        log_group = QGroupBox("📋 Журнал")
        log_layout = QVBoxLayout(log_group)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setFont(self.txt_log.font())
        self.txt_log.setMaximumHeight(150)
        log_layout.addWidget(self.txt_log)
        layout.addWidget(log_group)

        # Initial drive scan
        self._refresh_drives()

    def _log(self, msg):
        self.txt_log.append(msg)

    def _select_firmware(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Выберите прошивку", "",
            "RGN Firmware (*.rgn);;Все файлы (*.*)"
        )
        if path:
            self.fw_path = path
            size = os.path.getsize(path)
            self.lbl_fw_path.setText(f"✓ {os.path.basename(path)} ({size:,} байт)")
            self.btn_prepare_sd.setEnabled(True)
            self.btn_usb_flash.setEnabled(True)
            self._log(f"Выбран файл: {path}")

    def _refresh_drives(self):
        self.lst_drives.clear()
        drives = flasher.get_removable_drives()
        if not drives:
            self.lst_drives.addItem("Съёмные диски не найдены")
            return
        for d in drives:
            self.lst_drives.addItem(
                f"{d['label']} — {d['path']} "
                f"(свободно {d['free_gb']:.1f} / {d['total_gb']:.1f} ГБ)"
            )
        self._log(f"Найдено дисков: {len(drives)}")

    def _format_drive(self):
        row = self.lst_drives.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Внимание", "Выберите диск")
            return
        result = flasher.format_fat32("selected_drive")
        QMessageBox.information(self, "Форматирование FAT32",
                                result.get('instructions', ''))

    def _prepare_sd(self):
        if not hasattr(self, 'fw_path') or not self.fw_path:
            QMessageBox.warning(self, "Внимание", "Сначала выберите файл прошивки")
            return

        row = self.lst_drives.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Внимание", "Выберите SD-карту")
            return

        drives = flasher.get_removable_drives()
        if row >= len(drives):
            return

        drive_path = drives[row]['path']
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.btn_prepare_sd.setEnabled(False)
        self._log(f"Копирование на {drive_path}...")

        self._thread = SdPrepareThread(self.fw_path, drive_path)
        self._thread.progress.connect(self._log)
        self._thread.done.connect(self._on_sd_done)
        self._thread.start()

    def _on_sd_done(self, result):
        self.progress.setVisible(False)
        self.btn_prepare_sd.setEnabled(True)

        if result.get('success'):
            self._log(f"✓ {result['message']}")
            QMessageBox.information(self, "Готово",
                                    f"{result['message']}\n\n{result.get('instructions', '')}")
        else:
            self._log(f"✗ Ошибка: {result.get('error', '')}")
            QMessageBox.critical(self, "Ошибка", result.get('error', 'Неизвестная ошибка'))

    def _detect_garmin(self):
        device = flasher.detect_garmin_usb()
        if device:
            self._log(f"✓ Garmin найден: {device}")
            self.btn_usb_flash.setEnabled(True)
            QMessageBox.information(self, "Найдено", f"Garmin устройство: {device}")
        else:
            self._log("✗ Garmin устройство не найдено")
            QMessageBox.warning(self, "Не найдено",
                                "Garmin устройство не обнаружено.\n"
                                "Убедитесь что устройство подключено и включено.")

    def _usb_flash(self):
        if not flasher.check_pyserial():
            QMessageBox.warning(self, "Ошибка",
                                "Для USB-прошивки нужен pyserial.\n"
                                "pip install pyserial")
            return
        if not hasattr(self, 'fw_path'):
            QMessageBox.warning(self, "Внимание", "Сначала выберите прошивку")
            return
        QMessageBox.information(
            self, "USB Прошивка",
            "USB-прошивка через Garmin протокол находится в разработке.\n"
            "Пока используйте метод SD-карты."
        )
        self._log("USB-прошивка: в разработке")
