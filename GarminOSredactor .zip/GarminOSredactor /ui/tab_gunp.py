#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GUNP Tab — Firmware Analyzer / Decompiler.
Scans RGN files, finds language sections, displays them, exports, compares.
"""

import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton,
    QTableWidget, QTableWidgetItem, QTextEdit, QLabel, QFileDialog,
    QHeaderView, QMessageBox, QSplitter, QProgressBar, QComboBox
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont

from core.firmware_parser import FirmwareFile, compare_firmwares


class AnalyzeThread(QThread):
    finished_signal = pyqtSignal(object, str)
    error_signal = pyqtSignal(str)

    def __init__(self, filepath):
        super().__init__()
        self.filepath = filepath

    def run(self):
        try:
            fw = FirmwareFile.load(self.filepath)
            self.finished_signal.emit(fw, self.filepath)
        except Exception as e:
            self.error_signal.emit(str(e))


class GunpTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.firmware = None
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        # ── Top toolbar ──
        toolbar = QHBoxLayout()

        self.btn_open = QPushButton("📂 Открыть прошивку (.rgn)")
        self.btn_open.setProperty("class", "primary")
        self.btn_open.clicked.connect(self._open_firmware)
        toolbar.addWidget(self.btn_open)

        self.btn_export_all = QPushButton("💾 Экспорт всех языков")
        self.btn_export_all.clicked.connect(self._export_all)
        self.btn_export_all.setEnabled(False)
        toolbar.addWidget(self.btn_export_all)

        self.btn_export_sel = QPushButton("📥 Экспорт выбранного")
        self.btn_export_sel.clicked.connect(self._export_selected)
        self.btn_export_sel.setEnabled(False)
        toolbar.addWidget(self.btn_export_sel)

        self.btn_compare = QPushButton("🔄 Сравнить с...")
        self.btn_compare.clicked.connect(self._compare)
        self.btn_compare.setEnabled(False)
        toolbar.addWidget(self.btn_compare)

        toolbar.addStretch()

        self.lbl_file = QLabel("Файл не загружен")
        self.lbl_file.setProperty("class", "warning")
        toolbar.addWidget(self.lbl_file)

        layout.addLayout(toolbar)

        # ── File info ──
        self.lbl_info = QLabel("")
        self.lbl_info.setFont(QFont("Consolas", 10))
        self.lbl_info.setWordWrap(True)
        layout.addWidget(self.lbl_info)

        # ── Splitter: table (top) + strings (bottom) ──
        splitter = QSplitter(Qt.Vertical)

        # Language table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "#", "Язык", "Смещение", "Размер (байт)", "Строк", "Ср. байт/стр"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.cellClicked.connect(self._on_row_clicked)
        splitter.addWidget(self.table)

        # Strings viewer
        strings_group = QGroupBox("Строки выбранного языка")
        strings_layout = QVBoxLayout(strings_group)

        filter_bar = QHBoxLayout()
        filter_bar.addWidget(QLabel("Кодировка:"))
        self.cmb_encoding = QComboBox()
        self.cmb_encoding.addItems(['UTF-8', 'Windows-1251', 'CP437', 'Latin-1'])
        filter_bar.addWidget(self.cmb_encoding)

        self.btn_show_strings = QPushButton("Показать строки")
        self.btn_show_strings.clicked.connect(self._show_strings)
        filter_bar.addWidget(self.btn_show_strings)
        filter_bar.addStretch()
        strings_layout.addLayout(filter_bar)

        self.txt_strings = QTextEdit()
        self.txt_strings.setReadOnly(True)
        self.txt_strings.setFont(QFont("Consolas", 10))
        strings_layout.addWidget(self.txt_strings)

        splitter.addWidget(strings_group)
        splitter.setSizes([350, 250])
        layout.addWidget(splitter)

        # ── Progress bar ──
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        self.status_msg = ""

    def _open_firmware(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Открыть прошивку Garmin", "",
            "RGN Firmware (*.rgn);;Все файлы (*.*)"
        )
        if not path:
            return

        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.lbl_file.setText(f"Загрузка: {os.path.basename(path)}...")
        self.status_msg = f"Загрузка: {os.path.basename(path)}"

        self._thread = AnalyzeThread(path)
        self._thread.finished_signal.connect(self._on_analyzed)
        self._thread.error_signal.connect(self._on_error)
        self._thread.start()

    def _on_analyzed(self, fw, path):
        self.firmware = fw
        self.progress.setVisible(False)

        self.btn_export_all.setEnabled(True)
        self.btn_export_sel.setEnabled(True)
        self.btn_compare.setEnabled(True)
        self.lbl_file.setText(f"✓ {fw.filename}")
        self.lbl_file.setProperty("class", "success")

        h = fw.header
        info = (
            f"Файл: {fw.filename}  |  Размер: {fw.file_size:,} байт ({fw.file_size/1024/1024:.2f} МБ)  |  "
            f"Сигнатура: {h.signature_ascii}  |  Дата сборки: {h.build_date} {h.build_time}  |  "
            f"Языков найдено: {len(fw.languages)}"
        )
        self.lbl_info.setText(info)
        self._fill_table()
        self.status_msg = f"Загружен: {fw.filename} — {len(fw.languages)} языков"
        self.parent().parent().statusBar().showMessage(self.status_msg) if self.parent() and self.parent().parent() else None

    def _on_error(self, msg):
        self.progress.setVisible(False)
        QMessageBox.critical(self, "Ошибка", f"Не удалось открыть файл:\n{msg}")

    def _fill_table(self):
        if not self.firmware:
            return
        langs = self.firmware.languages
        self.table.setRowCount(len(langs))

        for i, sec in enumerate(langs):
            self.table.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            self.table.setItem(i, 1, QTableWidgetItem(sec.name))
            self.table.setItem(i, 2, QTableWidgetItem(f"{sec.offset:#010x}"))
            self.table.setItem(i, 3, QTableWidgetItem(f"{sec.size:,}"))
            self.table.setItem(i, 4, QTableWidgetItem(str(sec.string_count)))
            self.table.setItem(i, 5, QTableWidgetItem(f"{sec.avg_bytes_per_string:.1f}"))

        # Highlight first row
        if langs:
            self.table.selectRow(0)

    def _on_row_clicked(self, row, col):
        if self.firmware and row < len(self.firmware.languages):
            sec = self.firmware.languages[row]
            self._show_strings_for_section(sec)

    def _show_strings(self):
        row = self.table.currentRow()
        if self.firmware and 0 <= row < len(self.firmware.languages):
            sec = self.firmware.languages[row]
            self._show_strings_for_section(sec)

    def _show_strings_for_section(self, sec):
        enc = self.cmb_encoding.currentText()
        strings = sec.strings
        lines = [f"=== {sec.name} — {sec.string_count} строк, смещение {sec.offset:#x} ===\n"]
        for i, s in enumerate(strings):
            try:
                text = s.decode(enc, errors='replace')
            except Exception:
                text = repr(s)
            if len(text) > 120:
                text = text[:117] + "..."
            lines.append(f"[{i:>5}] {text}")

        self.txt_strings.setPlainText('\n'.join(lines))

    def _export_all(self):
        if not self.firmware:
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Выберите папку для экспорта")
        if not out_dir:
            return
        langs_dir = os.path.join(out_dir, "languages")
        os.makedirs(langs_dir, exist_ok=True)

        for i, sec in enumerate(self.firmware.languages):
            safe = sec.name.replace('\xe7', 'c').replace('\xf1', 'n').replace(
                '\xe9', 'e').replace('\xfc', 'u').replace('\xf6', 'o').replace(
                '\xe4', 'a').replace('\xe1', 'a')
            safe = ''.join(c if c.isalnum() or c in ' _-' else '_' for c in safe)
            path = os.path.join(langs_dir, f"lang_{i+1:03d}_{safe}.bin")
            self.firmware.export_language(i, path)

        # Index file
        idx_path = os.path.join(langs_dir, "language_index.txt")
        with open(idx_path, 'w', encoding='utf-8') as f:
            f.write(f"# Language Index — {self.firmware.filename}\n")
            f.write(f"# Size: {self.firmware.file_size:,} bytes\n")
            f.write(f"# Languages: {len(self.firmware.languages)}\n\n")
            for i, sec in enumerate(self.firmware.languages):
                f.write(f"  {i+1:>3}. {sec.name:<20} {sec.offset:#12x}  "
                        f"{sec.size:>10,} bytes  {sec.string_count} strings\n")

        QMessageBox.information(self, "Готово",
                                f"Экспортировано {len(self.firmware.languages)} языков\n"
                                f"Папка: {langs_dir}")

    def _export_selected(self):
        if not self.firmware:
            return
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Внимание", "Выберите язык в таблице")
            return
        sec = self.firmware.languages[row]
        safe = sec.name.replace('\xe7', 'c').replace('\xf1', 'n').replace(
            '\xe9', 'e').replace('\xfc', 'u').replace('\xf6', 'o')
        safe = ''.join(c if c.isalnum() or c in ' _-' else '_' for c in safe)
        path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить язык", f"lang_{row+1:03d}_{safe}.bin",
            "Binary (*.bin);;Все файлы (*.*)"
        )
        if path:
            self.firmware.export_language(row, path)
            QMessageBox.information(self, "Готово", f"Сохранено: {path}")

    def _compare(self):
        if not self.firmware:
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Выберите вторую прошивку для сравнения", "",
            "RGN Firmware (*.rgn);;Все файлы (*.*)"
        )
        if not path:
            return
        try:
            fw2 = FirmwareFile.load(path)
            result = compare_firmwares(self.firmware, fw2)
            self.txt_strings.setPlainText(result)
            self.table.parent().parent().setCurrentIndex(0)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def get_status(self):
        return self.status_msg
