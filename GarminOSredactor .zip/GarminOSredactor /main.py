#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GarminOSredactor — by bashgarminash
Complete Garmin firmware editing suite for GPSMAP 60/70 series.

Modules:
    GUNP      — firmware analyzer / decompiler
    Font Editor — bitmap font viewer & editor
    Flasher   — firmware installer (SD card + USB)
    Русификатор — Russian translation applicator
    Map Loader — Garmin map file manager

Usage:
    python main.py
"""

import sys
import os

# Ensure project root is in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

from ui.main_window import MainWindow


def main():
    # High DPI support
    if hasattr(Qt, 'AA_EnableHighDpiScaling'):
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    if hasattr(Qt, 'AA_UseHighDpiPixmaps'):
        QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setApplicationName("GarminOSredactor")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("bashgarminash")

    window = MainWindow()
    window.show()

    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
